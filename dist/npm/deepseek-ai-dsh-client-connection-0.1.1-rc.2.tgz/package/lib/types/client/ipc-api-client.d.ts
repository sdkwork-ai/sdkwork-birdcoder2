/**
 * Electron IPC carrier: the `AbstractApiClient` subclass whose `doFetch` and
 * stream openers ride the desktop bridge instead of HTTP/WebSocket. Protocol
 * invariants (rpcId minting, envelope validation, value parse) stay in the
 * base class; only the transport changes, exactly as the gui-layering note's
 * subclass table reserves for an IPC bridge.
 * @module @deepseek-ai/dsh-client-connection/ipc-api-client
 */
import type { ApiProxy, HostFrame, MuxFrame, RpcRequest } from './api.ts';
import { AbstractApiClient } from './api.ts';
import type { DesktopBridge } from './desktop-bridge.ts';
/**
 * Renderer-side desktop carrier. `doFetch` serializes the call over
 * {@link DesktopBridge.fetch} and rebuilds a `Response` from the plain-JSON
 * answer; `openMux`/`openHost` subscribe to the bridge's downlink streams and
 * yield validated frames with the same inbox/wake shape as the WebSocket
 * carrier.
 */
export declare class IpcApiClient extends AbstractApiClient {
    private readonly bridge;
    /**
     * @param bridge - the preload-exposed desktop bridge.
     * @param timeoutMs - bounded-unary deadline, forwarded to the base class.
     */
    constructor(bridge: DesktopBridge, timeoutMs?: number);
    /** The underlying bridge, for consumers that need transport facts. */
    get transport(): DesktopBridge;
    protected doFetch(input: URL, init?: RequestInit): Promise<Response>;
    protected openMux(_payload: Parameters<ApiProxy['events']['mux']>[0]['payload'], signal: AbortSignal, onOpen?: () => void): AsyncIterable<RpcRequest<MuxFrame>>;
    protected openHost(_payload: Parameters<ApiProxy['events']['host']>[0]['payload'], signal: AbortSignal, onOpen?: () => void): AsyncIterable<RpcRequest<HostFrame>>;
    private readIpcStream;
}
//# sourceMappingURL=ipc-api-client.d.ts.map