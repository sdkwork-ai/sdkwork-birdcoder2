/**
 * Browser caller for generic Connection unary RPC channels over the desktop
 * bridge — the IPC mirror of {@link createWebConnectionRpc}: same correlation
 * and envelope validation, transport swapped from `globalThis.fetch` to the
 * bridge.
 * @module @deepseek-ai/dsh-client-connection/ipc-rpc
 */
import type { ClientConnectionRpc } from '../rpc.ts';
import type { DesktopBridge } from './desktop-bridge.ts';
/**
 * Create the bridge-backed generic RPC caller.
 * @param bridge - the preload-exposed desktop bridge.
 * @returns caller that owns request correlation and response-envelope validation.
 */
export declare function createIpcConnectionRpc(bridge: DesktopBridge): ClientConnectionRpc;
//# sourceMappingURL=ipc-rpc.d.ts.map