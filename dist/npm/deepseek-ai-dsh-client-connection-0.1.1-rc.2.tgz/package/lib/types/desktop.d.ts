/**
 * Desktop carrier node half: provides the `desktopBridge` host service the
 * Electron main process wires to IPC. The web node half owns the
 * `connection` host service (its HTTP route and upgrade registrations are
 * inert over the desktop carrier); this row injects it and reuses its shared
 * fetch handler, so generic RPC channels, interceptors, and the privileged
 * pinning stay on the single HostConnectionService instance.
 * @module @deepseek-ai/dsh-client-connection/desktop
 */
import type { Context } from '@deepseek-ai/cordis';
import { Service } from '@deepseek-ai/cordis';
import type { HostFrame, MuxFrame, RpcRequest } from '@deepseek-ai/dsh-host-apiproxy/api';
/** Stable Cordis plugin name. */
export declare const name = "desktop-connection";
/** Service key under which the host bridge is provided. */
export declare const DESKTOP_BRIDGE_SERVICE = "desktopBridge";
/**
 * The host bridge surface the app's main process consumes: a fetch handler
 * for unary/respond plus the two event-stream openers.
 */
export interface DesktopBridgeHost {
    /**
     * Dispatch one unary/respond request (loopback-shaped URL expected).
     * @param request - the Request to route through the shared /api handler.
     * @returns the RPC response body as a Response.
     */
    fetch(request: Request): Promise<Response>;
    /** Open the all-session mux event stream (server→client frames). */
    openMux(signal: AbortSignal): AsyncIterable<RpcRequest<MuxFrame>>;
    /** Open the host-level event stream (server→client frames). */
    openHost(signal: AbortSignal): AsyncIterable<RpcRequest<HostFrame>>;
}
/**
 * The desktop bridge service: owns the shared fetch handler and lazily reads
 * the apiProxy for the event streams (the gateway mounts after this row, so
 * streams open only once the tree settled — the app starts them post-boot).
 */
export declare class DesktopBridgeService extends Service implements DesktopBridgeHost {
    private readonly fetchHandler;
    /**
     * @param ctx - owning desktop-connection plugin context.
     * @param fetchHandler - the shared /api fetch handler (unary + respond).
     */
    constructor(ctx: Context, fetchHandler: {
        fetch(request: Request): Promise<Response>;
    });
    fetch(request: Request): Promise<Response>;
    openMux(signal: AbortSignal): AsyncIterable<RpcRequest<MuxFrame>>;
    openHost(signal: AbortSignal): AsyncIterable<RpcRequest<HostFrame>>;
    private openStream;
}
/**
 * Mount the desktop carrier: inject the `connection` host service (provided by
 * the web node half, whose HTTP registrations are inert over the desktop
 * carrier) and reuse its shared fetch handler for the IPC surface, then
 * provide the `desktopBridge` service the app wires to IPC.
 * @param ctx - plugin context.
 */
export declare const inject: string[];
export declare function apply(ctx: Context): void;
//# sourceMappingURL=desktop.d.ts.map