/**
 * The shared /api dispatch fallback: privileged-method pinning plus the
 * apiProxy gateway, identical for the web and desktop carriers so both
 * surfaces enforce the same boundary. The 426 upgrade-required answer for the
 * event paths is web-carriage specific and stays in the web node half.
 * @module @deepseek-ai/dsh-client-connection/api-gateway
 */
import type { Context } from '@deepseek-ai/cordis';
import type { FetchHandler } from './http-bridge.ts';
/**
 * Compose the dispatch fallback for one host context: method extraction from
 * the /api pathname, loopback pinning of {@link PRIVILEGED_METHODS}, and
 * delegation to the mounted apiProxy gateway (404 when no gateway exists).
 * @param ctx - host plugin context carrying the apiProxy service.
 * @returns the fallback fetch handler.
 */
export declare function createApiGatewayFetch(ctx: Context): FetchHandler;
//# sourceMappingURL=api-gateway.d.ts.map