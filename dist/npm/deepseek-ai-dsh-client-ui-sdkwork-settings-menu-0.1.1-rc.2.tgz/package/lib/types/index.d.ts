/**
 * Host loader entry for the browser implementation exported from `./client`:
 * registers the durable GUI-onboarding settings section the shell's welcome
 * step persists to (the same namespace the shell it replaces registered, so
 * persisted acknowledgements stay valid across the swap).
 */
import type { Context } from '@deepseek-ai/cordis';
/** Register the durable GUI-onboarding section when a settings provider exists. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map