import type { SettingsMenuRootComponentProps } from './shell-contract.ts';
/**
 * Render the settings trigger, its hover menu, and the settings panel.
 * @param props - composed slot props (shell-contract.ts).
 * @returns the settings menu element tree.
 */
export declare function SettingsMenuRoot(props: SettingsMenuRootComponentProps): import("react").JSX.Element;
//# sourceMappingURL=SettingsMenuRoot.d.ts.map