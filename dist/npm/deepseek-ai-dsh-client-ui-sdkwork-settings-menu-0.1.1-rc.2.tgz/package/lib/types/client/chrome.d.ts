import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Trigger content props: the standard locale seat only. */
export type TriggerContentProps = PropsRuntime<'settings.trigger'> & PropsLocale<'settings.menu'>;
/** Header content props: the standard locale seat only. */
export type HeaderContentProps = PropsRuntime<'settings.header'> & PropsLocale<'settings.menu'>;
/**
 * Render the trigger content: the rail-form gear icon with a visually-hidden
 * label supplying the button's accessible name.
 * @param props - composed slot props.
 * @returns the trigger content fragment.
 */
export declare function TriggerContent({ t }: TriggerContentProps): import("react").JSX.Element;
/**
 * Render the panel title text.
 * @param props - composed slot props.
 * @returns the title text node.
 */
export declare function HeaderContent({ t }: HeaderContentProps): import("react").JSX.Element;
/** Close-button label text props: the standard locale seat only. */
export type CloseLabelProps = PropsRuntime<'settings.close'> & PropsLocale<'settings.menu'>;
/**
 * Render the close button's visually-hidden label text.
 * @param props - composed slot props.
 * @returns the label text node.
 */
export declare function CloseLabel({ t }: CloseLabelProps): import("react").JSX.Element;
//# sourceMappingURL=chrome.d.ts.map