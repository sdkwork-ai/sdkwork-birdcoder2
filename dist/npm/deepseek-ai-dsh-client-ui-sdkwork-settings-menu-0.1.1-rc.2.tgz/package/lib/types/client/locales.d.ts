/** Settings-menu shell and menu dictionaries; feature rows own their copy. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    trigger: string;
    title: string;
    close: string;
    openDocument: string;
    'openDocument.error': string;
    'general.nav': string;
    'menu.settings': string;
    'menu.appearance': string;
    'menu.appearance.light': string;
    'menu.appearance.dark': string;
    'menu.appearance.system': string;
    'menu.help': string;
    'menu.help.soon': string;
    'menu.feedback': string;
    'menu.checkUpdates': string;
    'menu.signIn': string;
    'menu.membership': string;
    'menu.points': string;
    'menu.logout': string;
};
/** The settings-menu namespace key union. */
export type SettingsMenuKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    trigger: string;
    title: string;
    close: string;
    openDocument: string;
    'openDocument.error': string;
    'general.nav': string;
    'menu.settings': string;
    'menu.appearance': string;
    'menu.appearance.light': string;
    'menu.appearance.dark': string;
    'menu.appearance.system': string;
    'menu.help': string;
    'menu.help.soon': string;
    'menu.feedback': string;
    'menu.checkUpdates': string;
    'menu.signIn': string;
    'menu.membership': string;
    'menu.points': string;
    'menu.logout': string;
};
//# sourceMappingURL=locales.d.ts.map