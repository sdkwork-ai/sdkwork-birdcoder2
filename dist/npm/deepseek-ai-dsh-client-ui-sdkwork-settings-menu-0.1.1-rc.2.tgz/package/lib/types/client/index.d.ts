/**
 * Settings menu + settings shell plugin, browser half: occupies the
 * `mode.rail.settings` seat with the hover settings menu (account header,
 * membership/points group, settings/appearance/help/check-updates group,
 * sign-out footer) and the centered settings panel with section navigation
 * and the onboarding coordinator, declares the settings slots, provides the
 * `ctx.account` anonymous-profile service, and registers the chrome content,
 * the local-document action, and the General section. The composition-level
 * override of ui-settings-general keeps that plugin disabled in the web
 * bundle patch; this package re-declares every settings seat so feature-owned
 * sections, rows, and onboarding steps mount unchanged.
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type SettingsMenuKey } from './locales.ts';
export type { CloseLabelProps, HeaderContentProps, TriggerContentProps, } from './chrome.tsx';
export type { GeneralSectionComponentProps, } from './GeneralSection.tsx';
export type { SettingsDocumentActionInjected, SettingsDocumentActionProps } from './SettingsDocumentAction.tsx';
export type { SettingsDocumentState } from './settings-document-store.ts';
export { SettingsDocumentStore } from './settings-document-store.ts';
export type { SettingsMenuKey } from './locales.ts';
export type { AccountProfile, AccountRuntime, AccountSource } from './account.ts';
export type { FeedbackProfile, FeedbackRuntime, FeedbackSource } from './feedback.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Shell chrome + menu copy owned by this package. */
        'settings.menu': SettingsMenuKey;
    }
}
/**
 * Required services (cordis fiber inject). The target slots are declared by
 * other entries whose activation order relative to this one is NOT
 * constrained; registrations depend on their slots through `slots.inject()`.
 */
export declare const inject: string[];
/**
 * Register the `settings.menu` dictionaries, the account service, the chrome
 * content, the General section, and the settings shell, each once its slot
 * declaration is on the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map