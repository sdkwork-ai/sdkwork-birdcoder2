/**
 * The update banner: a non-intrusive card on the frame's floating layer
 * (`shell.overlay`) that follows the main-process update state machine — an
 * offer with release notes, a download progress view, and the restart prompt.
 * Pure presentation over the preload's `updates` surface; absent the bridge
 * (web composition, fixture mode) the banner renders nothing.
 */
import type { ReactNode } from 'react';
import type { PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createUpdateBannerStore } from './update-banner-store.ts';
/** Injected business face: the preload's update actions. */
export interface UpdateBannerInjected {
    /** Start downloading the offered update. */
    download: () => void;
    /** Quit and run the downloaded installer. */
    install: () => void;
    /** Open the release page in the default browser (unsigned Phase A fallback). */
    openReleasePage: () => void;
    /** Dismiss the current offer until a different version arrives. */
    dismiss: () => void;
}
/** Full component props: root runtime share + store share + injected face. */
export type UpdateBannerProps = PropsRuntime<'shell.overlay'> & PropsStore<ReturnType<typeof createUpdateBannerStore>> & UpdateBannerInjected;
/**
 * Render the update banner for the offer/download/ready phases; every other
 * phase (idle, checking, disabled, installing) and a dismissed offer render
 * nothing. Download progress and the ready-to-install action cannot be hidden.
 * @param props - composed slot props.
 * @returns the banner card, or nothing while there is nothing to show.
 */
export declare function UpdateBanner({ download, install, openReleasePage, dismiss, useStore }: UpdateBannerProps): ReactNode;
//# sourceMappingURL=UpdateBanner.d.ts.map