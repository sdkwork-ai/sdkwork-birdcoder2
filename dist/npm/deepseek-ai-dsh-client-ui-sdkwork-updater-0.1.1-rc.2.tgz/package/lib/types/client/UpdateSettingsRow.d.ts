/**
 * The General-settings row for the desktop shell's update preferences: the
 * auto-check switch, the release channel select, the auto-download switch, a
 * manual check button, and a status line fed by the bridge-pushed update
 * state. This plugin is the desktop shell's chrome surface, so it owns the
 * shell preference row; the host-side namespace registration lives with the
 * shell's main process (apps/desktop/src/desktop-settings.ts). Renders nothing
 * until the settings scope accepts a section (the row never guesses a value
 * it cannot read).
 */
import type { ReactNode } from 'react';
import type { PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { DesktopUpdateState } from '@deepseek-ai/dsh-client-connection/client';
import type { createUpdateSettingsRowStore } from './update-settings-store.ts';
import type { UpdateChannel } from './update-settings.ts';
/** Injected business face: the durable preference writes and the manual check. */
export interface UpdateSettingsRowInjected {
    /** Persist the auto-check switch. */
    setAutoCheck: (value: boolean) => void;
    /** Persist the release channel. */
    setChannel: (value: UpdateChannel) => void;
    /** Persist the auto-download switch. */
    setAutoDownload: (value: boolean) => void;
    /** Ask the updater for a quiet check now. */
    check: () => void;
}
/** Full component props: root runtime share + store share + injected face. */
export type UpdateSettingsRowProps = PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createUpdateSettingsRowStore>> & UpdateSettingsRowInjected;
/**
 * The one-line status the row shows under the controls, derived from the
 * bridge-pushed update state; nothing when the updater is quiescent.
 * @param state - the mirrored update slice (only the fields this label reads).
 * @returns the status label, or undefined for quiet phases.
 */
export declare function updateStatusText(state: {
    phase: DesktopUpdateState['phase'];
    version?: string | undefined;
    error?: string | undefined;
}): string | undefined;
/** Human labels for the channel select options. */
export declare const CHANNEL_LABELS: Record<UpdateChannel, string>;
/**
 * Render the update preferences row.
 * @param props - composed slot props.
 * @returns the row element tree, or nothing before the scope has a value.
 */
export declare function UpdateSettingsRow({ setAutoCheck, setChannel, setAutoDownload, check, useStore }: UpdateSettingsRowProps): ReactNode;
//# sourceMappingURL=UpdateSettingsRow.d.ts.map