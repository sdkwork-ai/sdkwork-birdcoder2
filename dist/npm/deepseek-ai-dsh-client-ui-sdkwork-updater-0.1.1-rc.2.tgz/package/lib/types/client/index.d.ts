/**
 * Desktop shell update-UI plugin, browser half: renders the non-intrusive
 * update banner on the frame's floating layer (offer → download progress →
 * restart prompt, with the Phase A release-page fallback), owns the update
 * preferences row in General settings (auto-check, channel, auto-download,
 * manual check), and mirrors the main process's update state machine into the
 * two slot stores. The row lives in the dsh-desktop-app bundle patch only, so
 * the web composition never loads this plugin; the components still guard on
 * the preload surface's presence (fixture mode, accidental composition).
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export type { UpdateBannerInjected, UpdateBannerProps } from './UpdateBanner.tsx';
export type { UpdateSettingsRowInjected, UpdateSettingsRowProps } from './UpdateSettingsRow.tsx';
export { CHANNEL_LABELS, updateStatusText } from './UpdateSettingsRow.tsx';
/** Required services: the slot registry and the settings transport. */
export declare const inject: string[];
/**
 * Client plugin body: register the update banner and the update preferences
 * row, and mirror the bridge-pushed update state into both slot stores. Target
 * slots are declared by other entries, so each registration rides
 * `slots.inject` on its declaration lifetime (late activation, redeclaration,
 * teardown with the caller's fiber).
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map