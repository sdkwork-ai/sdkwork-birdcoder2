/**
 * Update banner slot store: the bridge-pushed update state snapshot plus the
 * same-version offer dismissal flag. The plugin's apply-world listener is the only
 * writer; the banner component reads via props.useStore.
 */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client';
import type { DesktopUpdateState } from '@deepseek-ai/dsh-client-connection/client';
/** Banner state mirrored from the bridge-pushed update states. */
export interface UpdateBannerState {
    /** Current update phase; 'idle' until the first bridge push. */
    phase: DesktopUpdateState['phase'];
    /** Whether this build can download and hand off its installer. */
    canInstall: boolean;
    /** Version the updater is offering or installing, while one is known. */
    version: string | undefined;
    /** GitHub release title, when the provider reported one. */
    releaseName: string | undefined;
    /** GitHub release body markdown, when the provider reported one. */
    releaseNotes: string | undefined;
    /** Download progress percent, while the phase is `downloading`. */
    progressPercent: number | undefined;
    /** Human-readable driver failure; cleared by the next check. */
    error: string | undefined;
    /** Version whose offer the user dismissed; progress and completion still render. */
    dismissedVersion: string | undefined;
}
/** Declared action shape giving the exported factory a stable return type. */
type UpdateBannerActions = {
    /** Mirror one bridge-pushed update state. */
    sync: (draft: UpdateBannerState, next: DesktopUpdateState) => void;
    /** Dismiss the current offer; a different version clears the dismissal. */
    dismiss: (draft: UpdateBannerState) => void;
};
/**
 * Declares the update banner state and dismiss surface.
 * @returns the store handle.
 */
export declare function createUpdateBannerStore(): EngineStoreHandle<UpdateBannerState, UpdateBannerActions>;
export {};
//# sourceMappingURL=update-banner-store.d.ts.map