/** Host registration for the app-mode surface preferences. */
import type { Context } from '@deepseek-ai/cordis';
export { SIDEBAR_VISIBLE_FIELD, UI_APP_MODES_NAMESPACE, UiAppModesSettingsSchema, type UiAppModesSettings, } from './app-modes-settings.ts';
/**
 * Register the durable app-mode surface section when the settings service is
 * composed (the browser scope binds the same namespace).
 * @param ctx - Host context that may acquire the settings service.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map