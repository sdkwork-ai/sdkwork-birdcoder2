/**
 * The General-settings row for the sidebar-visibility preference: a labeled
 * switch over the `ui-sdkwork-app-modes` settings namespace. The row mirrors the
 * durable preference (its switch state); turning it off collapses the
 * sidebar to its control rail immediately through `ctx.layout`, and the
 * preference is re-applied as the boot default on later starts. Renders
 * nothing until the settings scope accepts a section (the row never guesses
 * a value it cannot read).
 */
import type { ReactNode } from 'react';
import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createSidebarSettingsRowStore } from './sidebar-settings-store.ts';
/** Injected business face: the durable preference write plus the live layout apply. */
export interface SidebarSettingsRowInjected {
    /**
     * Persist the sidebar-visibility preference and apply it to the frame
     * immediately (false collapses the sidebar to its control rail).
     * @param value - whether the sidebar renders wide content.
     */
    setSidebarVisible: (value: boolean) => void;
}
/** Full component props: root runtime share + store share + injected face + locale seat. */
export type SidebarSettingsRowProps = PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createSidebarSettingsRowStore>> & SidebarSettingsRowInjected & PropsLocale<'appMode'>;
/**
 * Render the sidebar-visibility preference row.
 * @param props - composed slot props.
 * @returns the row element tree, or nothing before the scope has a value.
 */
export declare function SidebarSettingsRow({ setSidebarVisible, useStore, t }: SidebarSettingsRowProps): ReactNode;
//# sourceMappingURL=SidebarSettingsRow.d.ts.map