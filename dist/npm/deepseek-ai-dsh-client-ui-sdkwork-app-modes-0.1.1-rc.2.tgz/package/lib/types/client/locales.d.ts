/** `appMode` namespace dictionaries: mode names, rail tooltips, and settings-row copy. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'rail.label': string;
    'mode.code': string;
    'mode.work': string;
    'mode.code.label': string;
    'mode.work.label': string;
    'page.placeholder': string;
    'page.back': string;
    'sidebar.show': string;
    'sidebar.show.description': string;
};
/** The appMode namespace key union. */
export type AppModeKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'rail.label': string;
    'mode.code': string;
    'mode.work': string;
    'mode.code.label': string;
    'mode.work.label': string;
    'page.placeholder': string;
    'page.back': string;
    'sidebar.show': string;
    'sidebar.show.description': string;
};
//# sourceMappingURL=locales.d.ts.map