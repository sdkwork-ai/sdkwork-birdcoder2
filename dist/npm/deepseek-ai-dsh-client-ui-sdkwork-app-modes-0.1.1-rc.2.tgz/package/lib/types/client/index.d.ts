/**
 * App-mode surface plugin, browser half: registers the mode rail shell into
 * the frame's `mode.rail` track (including the bottom-pinned
 * `mode.rail.settings` seat, occupied by ui-settings-general's trigger +
 * panel), the base rail entries into the keyed
 * `mode.rail.entry` seat (later modes come from their own packages), the
 * placeholder pages into the keyed `mode.page` slot (one entry per non-code
 * base mode), and the sidebar-visibility preference row into the settings
 * General section. The active mode state lives in the layout store (the
 * frame's own store — AppFrame reads it for the center column and hands it
 * to the rail as owner props), so this plugin holds no mode state of its
 * own. The persisted sidebar preference is applied as the boot default once
 * the settings scope resolves, and live on row changes.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type AppModeKey } from './locales.ts';
export type { ModePageInjected, ModePageProps, } from './ModePage.tsx';
export type { ModeRailInjected, ModeRailProps } from './ModeRail.tsx';
export type { RailEntryInjected, RailEntryProps, } from './RailEntry.tsx';
export type { SidebarSettingsRowInjected, SidebarSettingsRowProps, } from './SidebarSettingsRow.tsx';
export type { SidebarSettingsRowState } from './sidebar-settings-store.ts';
export type { BaseAppModeId } from './base-modes.ts';
export type { ModeIconProps } from './icons.tsx';
export type { AppModeKey } from './locales.ts';
export type { ModeRailEntryOwnerProps, ModeRailSettingsOwnerProps } from './contract/slots.ts';
export type { UiAppModesSettings } from '../app-modes-settings.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The app-mode surface's copy (rail shell, base entries, pages, settings row). */
        appMode: AppModeKey;
    }
}
/** Services required by the app-mode surface plugin. */
export declare const inject: string[];
/**
 * Client plugin body: register the rail shell, the base rail entries, the
 * placeholder pages, and the sidebar-visibility preference row, each once
 * its slot declaration is on the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map