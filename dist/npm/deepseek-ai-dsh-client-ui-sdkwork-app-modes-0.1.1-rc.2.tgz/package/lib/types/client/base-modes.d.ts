/**
 * The base app modes: the ones the app-mode surface plugin itself owns
 * (rail entries, icons, placeholder pages). Later modes are independent
 * modules — their ids join the frame's AppModeId union, but their glyphs,
 * copy, and pages live in their own packages. Video and Image moved out
 * with the SDKWork Agents generation plugins (ui-sdkwork-generations-video,
 * ui-sdkwork-generations-image).
 */
/** The base modes still owned by this package. */
export type BaseAppModeId = 'code' | 'work';
/** The base mode ids, in rail order. */
export declare const BASE_MODES: readonly BaseAppModeId[];
//# sourceMappingURL=base-modes.d.ts.map