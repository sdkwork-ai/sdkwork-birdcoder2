/**
 * Placeholder mode page: the center-column surface for a mode without a real
 * product yet (Work/Video/Image/AppStore). The mode id arrives through the
 * keyed registration's inject closure; the page renders a hero glyph, the
 * mode name, and a construction notice with a hint back to the Code
 * workbench.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BaseAppModeId } from './base-modes.ts';
/** Injected business face: which mode this keyed entry renders. */
export interface ModePageInjected {
    /** The placeholder page's own mode id (the keyed registration's key). */
    mode: BaseAppModeId;
}
/** Full component props: runtime share + injected mode + the locale seat. */
export type ModePageProps = PropsRuntime<'mode.page'> & ModePageInjected & PropsLocale<'appMode'>;
/**
 * Render a placeholder mode page.
 * @param props - composed slot props (contract share + injected mode + locale seat).
 * @returns the page element tree.
 */
export declare function ModePage({ mode, t }: ModePageProps): import("react").JSX.Element;
//# sourceMappingURL=ModePage.d.ts.map