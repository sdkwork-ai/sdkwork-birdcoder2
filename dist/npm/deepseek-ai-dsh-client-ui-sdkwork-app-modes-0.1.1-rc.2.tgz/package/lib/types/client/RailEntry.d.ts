import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BaseAppModeId } from './base-modes.ts';
/** Injected business face: which mode this keyed entry renders. */
export interface RailEntryInjected {
    /** The entry's own mode id (the keyed registration's key). */
    mode: BaseAppModeId;
}
/** Full component props: runtime share (owner + standard) + injected mode + locale seat. */
export type RailEntryProps = PropsRuntime<'mode.rail.entry'> & RailEntryInjected & PropsLocale<'appMode'>;
/**
 * Render one mode-rail entry cell.
 * @param props - composed slot props (owner share + injected mode + locale seat).
 * @returns the entry button element tree.
 */
export declare function RailEntry({ mode, active, setMode, t }: RailEntryProps): import("react").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map