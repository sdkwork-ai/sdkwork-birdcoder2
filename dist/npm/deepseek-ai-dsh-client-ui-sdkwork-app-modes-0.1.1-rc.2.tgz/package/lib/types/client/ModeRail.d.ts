import type { PropsLocale, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AppModeId } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { AuthenticatedModeGate } from '@deepseek-ai/dsh-client-ui-sdkwork-iam/client';
/** Rail entry order (top-down, WeChat-desktop style; 'work' temporarily hidden). */
export declare const MODE_ORDER: readonly AppModeId[];
/** Optional IAM gate injected by ui-sdkwork-app-modes when ui-sdkwork-iam is on the boot graph. */
export interface ModeRailInjected {
    /** Live IAM session face for gated mode switches; omitted without ui-sdkwork-iam. */
    authGate?: AuthenticatedModeGate;
}
/** Full component props: layout owner share + the render share + the locale seat. */
export type ModeRailProps = PropsRuntime<'mode.rail'> & ModeRailInjected & PropsRenderSlots<'mode.rail.entry' | 'mode.rail.settings'> & PropsLocale<'appMode'>;
/**
 * Render the app-mode rail with Token Plan and Settings adjacent at the bottom.
 * @param props - composed slot props (owner share + render slots + locale seat).
 * @returns the rail element tree.
 */
export declare function ModeRail({ mode, setMode, authGate, t, renderSlot }: ModeRailProps): import("react").JSX.Element;
//# sourceMappingURL=ModeRail.d.ts.map