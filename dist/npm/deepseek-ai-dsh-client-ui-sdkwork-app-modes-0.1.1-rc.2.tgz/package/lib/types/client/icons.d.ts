/**
 * Self-contained 24px glyphs for the base app modes, in two weights: the
 * outline set (stroke) for idle rail entries and the placeholder pages, and
 * the filled set (solid) for the rail's active entry — the WeChat-style
 * selection swaps the glyph weight along with the background. The
 * design-system icon set (ui-primitives) has no Work vocabulary, so the rail
 * owns its glyphs; they follow the shared icon contract ({size, className},
 * color rides currentColor) so swapping in library icons later is local.
 */
import type { FC } from 'react';
import type { BaseAppModeId } from './base-modes.ts';
/** Shared props for every mode glyph. */
export interface ModeIconProps {
    /** Square edge in px. */
    size?: number | undefined;
    /** Extra class for layout placement; color rides currentColor. */
    className?: string | undefined;
}
/** Code mode, outline: chevron pair (`</>`). */
export declare const CodeIcon: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Code mode, filled: solid chevron brackets (the canonical code glyph). */
export declare const CodeIconFilled: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Work mode, outline: briefcase. */
export declare const WorkIcon: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Work mode, filled: solid briefcase with the handle knocked out. */
export declare const WorkIconFilled: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Mode id → outline glyph map (idle rail entries and placeholder pages). */
export declare const MODE_ICONS: Record<BaseAppModeId, FC<ModeIconProps>>;
/** Mode id → filled glyph map (the rail's active entry). */
export declare const MODE_ICONS_FILLED: Record<BaseAppModeId, FC<ModeIconProps>>;
//# sourceMappingURL=icons.d.ts.map