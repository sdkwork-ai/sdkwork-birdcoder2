/** SDKWork deployment environment settings stored in the Host user-settings document. */
import z from '@deepseek-ai/schemastery';
/** Settings namespace owned by the ui-sdkwork-env plugin. */
export declare const UI_ENV_NAMESPACE = "ui-sdkwork-env";
/** The deployment environments every sdkwork integration profile belongs to. */
export type SdkworkEnvironment = 'development' | 'testing' | 'production';
/** Field selecting the active environment. */
export declare const UI_ENV_ENVIRONMENT_FIELD = "environment";
/** One environment's sdkwork integration facts, shared by every consuming plugin. */
export interface SdkworkEnvProfile {
    /** SDKWork API gateway origin (IAM auth + API clients). */
    apiBaseUrl: string;
    /** Tenant application id reported to the IAM backend. */
    appId: string;
    /** Product app key reported to platform collectors (e.g. feedback). */
    appKey: string;
    /** Static access token for non-interactive API calls; empty falls back to the IAM session. */
    accessToken: string;
}
/** Durable ui-sdkwork-env section shared by the Host schema and the browser scope. */
export interface UiEnvSettings {
    /** The active environment; its profile feeds every sdkwork integration. */
    environment: SdkworkEnvironment;
    development: SdkworkEnvProfile;
    testing: SdkworkEnvProfile;
    production: SdkworkEnvProfile;
}
/** Durable ui-sdkwork-env schema; also the wire envelope the browser scope validates against. */
export declare const UiEnvSettingsSchema: z<UiEnvSettings>;
/** The schema defaults, for reads before the settings scope resolves. */
export declare const DEFAULT_UI_ENV_SETTINGS: UiEnvSettings;
//# sourceMappingURL=env-settings.d.ts.map