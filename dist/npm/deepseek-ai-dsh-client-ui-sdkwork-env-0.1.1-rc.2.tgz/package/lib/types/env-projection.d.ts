/**
 * Launch-environment projection for the ui-sdkwork-env settings section: resolve the
 * deployment profile the launch environment declares and project its base URL
 * and bootstrap access token into the settings composition `base` layer, so
 * every SDKWork integration plugin reads them through `ctx.env` without the
 * user editing the settings document. The user layer still wins: the settings
 * service resolves schema defaults, then this base, then the user document.
 * @module @deepseek-ai/dsh-client-ui-sdkwork-env/env-projection
 */
import type { LaunchEnvironmentSnapshot } from '@deepseek-ai/dsh-launch-environment';
import type { SdkworkEnvironment, UiEnvSettings } from './env-settings.ts';
/**
 * SDKWork surface URL keys in priority order (ENVIRONMENT_SPEC.md section 6):
 * the platform API gateway origin, then the app-api base URL, then the
 * application public ingress — the first non-empty value wins.
 */
export declare const SDKWORK_BASE_URL_KEYS: readonly ["SDKWORK_BIRDCODER_PLATFORM_API_GATEWAY_HTTP_URL", "SDKWORK_BIRDCODER_APP_API_BASE_URL", "SDKWORK_BIRDCODER_APPLICATION_PUBLIC_HTTP_URL"];
/**
 * Resolve the ui-sdkwork-env environment slot the launch environment declares.
 * @param env - the launch environment snapshot.
 * @returns the ui-sdkwork-env slot, or `undefined` when no SDKWork environment key is
 * declared or the value names an unsupported tier.
 */
export declare function resolveUiEnvEnvironment(env: LaunchEnvironmentSnapshot): SdkworkEnvironment | undefined;
/**
 * Build the settings composition `base` layer from the launch environment: the
 * active environment slot plus that slot's profile fields the environment
 * declares (base URL and bootstrap access token). Absent keys stay on the
 * schema defaults; the user settings document still overrides everything.
 * @param env - the launch environment snapshot.
 * @returns the projected base layer, empty when no SDKWork environment is declared.
 */
export declare function projectSdkworkEnvBase(env: LaunchEnvironmentSnapshot): Partial<UiEnvSettings>;
//# sourceMappingURL=env-projection.d.ts.map