/**
 * The deployment environment service: mirrors the `ui-sdkwork-env` settings scope
 * and exposes the ACTIVE environment's profile — one base URL, app id, app
 * key, and access token shared by every sdkwork integration plugin, so a
 * deployment switches environments in one place instead of per-plugin
 * settings.
 */
import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client';
import { type SdkworkEnvProfile, type SdkworkEnvironment, type UiEnvSettings } from '../env-settings.ts';
/**
 * Environment service: settings mirror + active-profile projection.
 */
export declare class EnvService {
    private readonly scope;
    constructor(scope: SettingsScope<UiEnvSettings>);
    /** The current settings snapshot (schema defaults until the scope resolves). */
    currentSettings(): UiEnvSettings;
    /** The active environment selector. */
    currentEnvironment(): SdkworkEnvironment;
    /** The active environment's integration profile. */
    profile(): SdkworkEnvProfile;
    /** Whether the active environment carries a usable API gateway origin. */
    isConfigured(): boolean;
    /** The active environment's API gateway origin. */
    apiBaseUrl(): string;
    /** The active environment's IAM tenant application id. */
    appId(): string;
    /** The active environment's product app key. */
    appKey(): string;
    /** The active environment's static access token (empty means IAM-session auth). */
    accessToken(): string;
    /**
     * Observe environment or profile changes.
     * @param listener - the change listener.
     * @returns the disposer removing this listener.
     */
    subscribe(listener: () => void): () => void;
}
//# sourceMappingURL=env-service.d.ts.map