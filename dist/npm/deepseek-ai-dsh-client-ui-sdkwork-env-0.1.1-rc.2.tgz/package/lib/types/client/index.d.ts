/**
 * SDKWork deployment environment plugin, browser half: provides the
 * `ctx.env` service (settings mirror + active-profile projection) that every
 * sdkwork integration plugin consumes for its base URL, app id, app key, and
 * static access token. The `ui-sdkwork-env` settings scope (active environment plus
 * one profile per environment) lands from the Host settings document.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { EnvService } from './env-service.ts';
export { EnvService } from './env-service.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The deployment environment service (shared by sdkwork integration plugins). */
        env: EnvService;
    }
}
/** Services required by the ui-sdkwork-env plugin (cordis fiber inject). */
export declare const inject: string[];
/**
 * Register the environment service once its settings scope is available.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map