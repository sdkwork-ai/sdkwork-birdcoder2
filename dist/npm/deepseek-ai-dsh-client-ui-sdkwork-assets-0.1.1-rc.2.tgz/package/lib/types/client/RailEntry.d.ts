import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business face: this entry's mode id (the keyed registration's key). */
export interface AssetsRailEntryInjected {
    /** The entry's own mode id. */
    mode: 'assets';
}
/** Full component props: runtime share (owner + standard) + injected mode + locale seat. */
export type AssetsRailEntryProps = PropsRuntime<'mode.rail.entry'> & AssetsRailEntryInjected & PropsLocale<'assets'>;
/**
 * Render the Assets rail entry cell.
 * @param props - composed slot props (owner share + injected mode + locale seat).
 * @returns the entry button element tree.
 */
export declare function AssetsRailEntry({ mode, active, setMode, t }: AssetsRailEntryProps): import("react").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map