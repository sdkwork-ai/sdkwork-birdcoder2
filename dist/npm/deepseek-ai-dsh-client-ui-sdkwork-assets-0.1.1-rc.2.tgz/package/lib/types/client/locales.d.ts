/** `assets` namespace dictionaries: the rail entry and page copy. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.assets': string;
    'mode.assets.label': string;
    'page.placeholder': string;
    'page.back': string;
};
/** The assets namespace key union. */
export type AssetsKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.assets': string;
    'mode.assets.label': string;
    'page.placeholder': string;
    'page.back': string;
};
//# sourceMappingURL=locales.d.ts.map