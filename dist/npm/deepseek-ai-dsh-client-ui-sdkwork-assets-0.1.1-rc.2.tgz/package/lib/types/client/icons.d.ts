/**
 * Self-contained 24px Assets glyphs in two weights: the outline set for idle
 * rail entries and the page, the filled set for the rail's active entry.
 * Follows the shared icon contract ({size, className}, color rides
 * currentColor).
 */
import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Assets mode, outline: cube with its top edges. */
export declare const AssetIcon: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Assets mode, filled: solid cube with the top face knocked out. */
export declare const AssetIconFilled: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
//# sourceMappingURL=icons.d.ts.map