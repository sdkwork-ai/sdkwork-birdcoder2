/**
 * The Assets placeholder page: the center-column surface for the
 * `assets` mode, keyed into the frame's `mode.page` slot. Renders a hero
 * glyph, the mode name, and a construction notice with a hint back to the
 * Code workbench.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business face: which mode this keyed entry renders. */
export interface AssetsPageInjected {
    /** The page's own mode id (the keyed registration's key). */
    mode: 'assets';
}
/** Full component props: runtime share + injected mode + the locale seat. */
export type AssetsPageProps = PropsRuntime<'mode.page'> & AssetsPageInjected & PropsLocale<'assets'>;
/**
 * Render the Assets placeholder page.
 * @param props - composed slot props (contract share + injected mode + locale seat).
 * @returns the page element tree.
 */
export declare function AssetsPage({ mode, t }: AssetsPageProps): import("react").JSX.Element;
//# sourceMappingURL=AssetsPage.d.ts.map