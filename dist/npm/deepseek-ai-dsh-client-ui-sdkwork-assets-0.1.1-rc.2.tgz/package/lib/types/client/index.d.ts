/**
 * Assets mode plugin, browser half: registers its rail entry into
 * the keyed `mode.rail.entry` seat (declared by ui-sdkwork-app-modes' rail shell)
 * and its placeholder page into the keyed `mode.page` seat (declared by
 * ui-layout's frame), both keyed by the `assets` mode id. The mode is an
 * independent module: glyphs, copy, and page live here and can grow into
 * the real Assets surface without touching the rail shell or the
 * frame.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type AssetsKey } from './locales.ts';
export type { AssetsPageInjected, AssetsPageProps, } from './AssetsPage.tsx';
export type { AssetsRailEntryInjected, AssetsRailEntryProps, } from './RailEntry.tsx';
export type { AssetsKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Assets mode's copy (rail entry + page). */
        assets: AssetsKey;
    }
}
/** Services required by the Assets mode plugin. */
export declare const inject: string[];
/**
 * Client plugin body: register the rail entry and the placeholder page, each
 * once its slot declaration is on the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map