/**
 * Scoped SDKWork host theme shell: follows the harness color scheme, applies a
 * local `.dark` wrapper for tailwind descendants, and mirrors the scheme onto
 * `document.documentElement` while mounted so legacy SDKWork surfaces that read
 * the root class list stay aligned with BirdCoder appearance settings.
 */
import { type ReactNode } from 'react';
import type { HostThemeBridge } from './host-theme-bridge.ts';
/** Props for the embedded SDKWork theme shell. */
export interface SdkworkHostThemeSurfaceProps {
    /** Host theme bridge wired from {@link createHostThemeBridge}. */
    theme: HostThemeBridge;
    /** Optional `data-*` marker for tests and surface-scoped CSS. */
    surface?: string;
    /** Embedded SDKWork body. */
    children: ReactNode;
    /** Optional extra class names on the shell root. */
    className?: string;
}
/**
 * Render embedded SDKWork content under a host-managed color scheme.
 * @param props - theme bridge, optional surface marker, and children.
 * @returns the themed shell element tree.
 */
export declare function SdkworkHostThemeSurface({ theme, surface, children, className, }: SdkworkHostThemeSurfaceProps): import("react").JSX.Element;
//# sourceMappingURL=SdkworkHostThemeSurface.d.ts.map