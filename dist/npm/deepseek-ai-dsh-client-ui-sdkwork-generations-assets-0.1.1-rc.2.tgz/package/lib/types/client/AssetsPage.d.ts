/**
 * The assets page: the center-column surface for the `assets` mode, keyed into
 * the frame's `mode.page` slot. Mounts the SDKWork Agents assets (资产) PC
 * surface through this plugin's host adapter after IAM reports signed in.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type AuthenticatedSdkworkModePageInjected } from '@deepseek-ai/dsh-client-ui-sdkwork-iam/client';
/** Injected business face: which mode this keyed entry renders. */
export interface AssetsPageInjected extends AuthenticatedSdkworkModePageInjected {
    /** The page's own mode id (the keyed registration's key). */
    mode: 'assets';
}
/** Full component props: runtime share + injected mode + the locale seat. */
export type AssetsPageProps = PropsRuntime<'mode.page'> & AssetsPageInjected & PropsLocale<'generationsAssets'>;
/**
 * Render the SDKWork Agents assets (资产) page.
 * @param props - composed slot props (contract share + injected mode + locale seat).
 * @returns the page element tree.
 */
export declare function AssetsPage({ mode, authGate, t }: AssetsPageProps): import("react").JSX.Element;
//# sourceMappingURL=AssetsPage.d.ts.map