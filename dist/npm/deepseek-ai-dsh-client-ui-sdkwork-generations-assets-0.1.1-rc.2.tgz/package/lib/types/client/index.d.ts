/**
 * Generated-assets mode plugin, browser half: registers its rail entry into
 * the keyed `mode.rail.entry` seat (declared by ui-sdkwork-app-modes' rail shell)
 * and the SDKWork Agents assets (资产) page into the keyed `mode.page` seat
 * (declared by ui-layout's frame), both keyed by the `assets` mode id. The
 * registrations shadow the placeholder entries of `@deepseek-ai/dsh-client-ui-sdkwork-assets`
 * at a lower priority, so the real library renders while the placeholder
 * package stays untouched. The host adapter is configured from the shared
 * environment, IAM, and locale services before the embedded {@link AssetsView}
 * can mount.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type AssetsGenerationsKey } from './locales.ts';
export type { AssetsPageInjected, AssetsPageProps, } from './AssetsPage.tsx';
export type { AssetsGenerationsRailEntryInjected, AssetsGenerationsRailEntryProps, } from './RailEntry.tsx';
export type { AssetsHostAdapter, AssetsHostEnvironment, AssetsHostIam, AssetsHostLocale, AssetsHostRuntime, AssetsHostSession, ConfigureAssetsHostOptions, } from './assetsHost.ts';
export type { AssetsGenerationsKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The generated-assets mode's copy (rail entry). */
        generationsAssets: AssetsGenerationsKey;
    }
}
/** Services required by the generated-assets mode plugin. */
export declare const inject: string[];
/**
 * Register the assets host adapter, rail entry, and page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map