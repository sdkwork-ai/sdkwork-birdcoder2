/** `generationsAssets` namespace dictionaries: the rail entry only. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.assets': string;
    'mode.assets.label': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
/** The generationsAssets namespace key union. */
export type AssetsGenerationsKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.assets': string;
    'mode.assets.label': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
//# sourceMappingURL=locales.d.ts.map