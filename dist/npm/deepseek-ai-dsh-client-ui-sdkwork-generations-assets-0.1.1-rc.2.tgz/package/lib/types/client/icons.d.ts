/**
 * Self-contained 24px glyphs for the generated-assets mode, in two weights:
 * the outline set (stroke) for the idle rail entry and the filled set (solid)
 * for the rail's active entry. They follow the shared icon contract
 * ({size, className}, color rides currentColor).
 */
import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Generated-assets mode, outline: cube with its top edges. */
export declare const AssetsGenIcon: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Generated-assets mode, filled: solid cube with the top face knocked out. */
export declare const AssetsGenIconFilled: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
//# sourceMappingURL=icons.d.ts.map