/**
 * BirdCoder host adapter for the SDKWork Agents assets (资产) PC surface.
 *
 * The adapter owns assets SDK client construction and maps the shared ui-sdkwork-env
 * and ui-sdkwork-iam services to the Agents PC session store and Assets SDK client
 * provider. The embedded {@link AssetsView} is remounted when the API
 * environment changes; IAM and locale changes flow through the session bridge.
 */
import { type ReactNode } from 'react';
import { type SdkworkChatSession } from '@sdkwork/agents-pc-core/session';
import { type HostThemeBridge } from './sdkworkHostThemeSurface.tsx';
import '../../../../../../sdkwork-agents/apps/sdkwork-agents-pc/src/index.css';
/** Environment values consumed by the SDKWork host adapter. */
export interface AssetsHostEnvironment {
    /** @returns the active API gateway origin. */
    apiBaseUrl(): string;
    /** @returns the configured static access token, if any. */
    accessToken(): string;
    /** Observe profile or active-environment changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal IAM controller state consumed by the adapter. */
export interface AssetsHostIam {
    controller: {
        /** @returns the current session, when authenticated. */
        getState(): {
            session: AssetsHostSession | null;
        };
        /** Observe login, refresh, and sign-out changes. */
        subscribe(listener: () => void): () => void;
    };
}
/** Minimal locale runtime consumed by the adapter. */
export interface AssetsHostLocale {
    /** @returns the active BirdCoder locale id. */
    getSnapshot(): {
        active: string;
    };
    /** Observe active-locale changes. */
    subscribe(listener: () => void): () => void;
}
/** IAM session fields accepted by the Agents PC session bridge. */
export interface AssetsHostSession {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: {
        id?: string;
        displayName?: string;
        email?: string;
        avatar?: unknown;
    };
}
/** Minimal theme runtime consumed by the adapter. */
export interface AssetsHostTheme extends HostThemeBridge {
}
/** Dependencies used to configure the SDKWork surface. */
export interface ConfigureAssetsHostOptions {
    env: AssetsHostEnvironment;
    iam: AssetsHostIam;
    locale: AssetsHostLocale;
    theme: AssetsHostTheme;
}
/**
 * Normalize the gateway origin for SDKWork app clients.
 * @param baseUrl - active API gateway origin from ui-sdkwork-env.
 * @returns the gateway root without a duplicated app API suffix.
 */
export declare function normalizeAssetsGatewayBaseUrl(baseUrl: string): string;
/**
 * Convert the host IAM state into the Agents PC session format.
 * Identity fields are resolved inside Agents PC from JWT claims; the host
 * forwards credentials only and lets session tokens supersede env bootstrap.
 * @param session - current host IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token used by non-interactive deployments.
 * @returns a credential snapshot, or null when no tokens are available.
 */
export declare function toAssetsSession(session: AssetsHostSession | null, staticAccessToken: string): SdkworkChatSession | null;
/** Lifecycle handle returned after configuring the SDKWork host. */
export interface AssetsHostAdapter {
    /** Dispose environment and IAM subscriptions. */
    dispose(): void;
}
/** Observable host-adapter operations used by focused integration tests. */
export interface AssetsHostRuntime extends AssetsHostAdapter {
    /** Start environment and IAM subscriptions. */
    start(): () => void;
    /** Register a listener for adapter changes. */
    subscribe(listener: () => void): () => void;
    /** @returns the revision used to remount after an environment switch. */
    getEnvironmentRevision(): number;
    /** @returns the active SDKWork locale tag. */
    resolveHostLanguage(): string;
}
/** Configure the Assets SDK client provider for the embedded assets surface. */
export declare function configureAssetsHost(options: ConfigureAssetsHostOptions): AssetsHostAdapter;
/** Build an unconfigured adapter for focused host-bridge tests. */
export declare function createAssetsHostRuntime(options: ConfigureAssetsHostOptions): AssetsHostRuntime;
/** Render the SDKWork Agents assets surface through the configured host adapter. */
export declare function AssetsApp(): ReactNode;
//# sourceMappingURL=assetsHost.d.ts.map