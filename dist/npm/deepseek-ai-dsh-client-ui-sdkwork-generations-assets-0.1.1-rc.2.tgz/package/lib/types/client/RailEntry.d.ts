import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business data for the generated-assets rail entry. */
export interface AssetsGenerationsRailEntryInjected {
    /** The keyed mode id owned by this entry. */
    mode: 'assets';
}
/** Composed props for the generated-assets rail entry. */
export type AssetsGenerationsRailEntryProps = PropsRuntime<'mode.rail.entry'> & AssetsGenerationsRailEntryInjected & PropsLocale<'generationsAssets'>;
/**
 * Render the assets rail button; swaps to the filled glyph while active.
 * @param props - mode selection owner data, injected id, and locale seat.
 * @returns the rail button.
 */
export declare function AssetsGenerationsRailEntry({ mode, active, setMode, t }: AssetsGenerationsRailEntryProps): import("react").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map