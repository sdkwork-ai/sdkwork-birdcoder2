/**
 * @deepseek-ai/dsh-sdkwork-desktop-carrier — the Electron desktop carrier: a
 * `webServer`-service-shaped route registry that is driven by the desktop
 * shell's `app://` protocol handler instead of node:http. It knows no harness
 * concepts and serves no files; the composing application's frontend plugin
 * owns dist serving through the fallback hook, exactly like the web carrier.
 * The web composition (client-modules bundle route + boot-manifest index tap,
 * frontend-static fallback, ui-theme index tap) mounts unchanged over it —
 * the sdkwork-desktop-app bundle swaps the `webserver` row for this package, and the
 * app's protocol handler calls {@link DesktopWebServer.dispatch} per request.
 */
import type { Context } from '@deepseek-ai/cordis';
import { Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { WebRoute, WebUpgradeRoute } from '@deepseek-ai/dsh-host-webserver';
import { type IndexInjection } from '@deepseek-ai/dsh-host-webserver';
/** Gateway config, mirroring the web carrier: the listen address the web composition reads. */
export interface Config {
    /** Loopback or all-interfaces literal; the desktop shell never binds, the value is informational. */
    host: '127.0.0.1' | '0.0.0.0';
    /** Informational port (the desktop shell opens no socket). */
    port: number;
}
/** Config schema, mirroring the web carrier's (both the module export and the class static). */
export declare const Config: z<Config>;
/**
 * The desktop browser carrier service: the same route/fallback/index-tap
 * registries as the web carrier, delivered through {@link dispatch} instead of
 * a listening socket. It never opens a port — Electron loads the built
 * frontend over `app://` and carries RPC over IPC, so this service exists to
 * keep the composition's `webServer` consumers working verbatim.
 */
export declare class DesktopWebServer extends Service {
    private readonly config;
    static Config: z<Config>;
    private readonly exact;
    private readonly prefixes;
    private readonly upgrades;
    private readonly indexTaps;
    private fallback;
    constructor(ctx: Context, config: Config);
    /** The configured bind literal (informational; the shell opens no socket). */
    get host(): Config['host'];
    /** The configured port (informational; the shell opens no socket). */
    get port(): number;
    /**
     * Register a named route. Duplicate (kind, path) throws — route patterns are
     * a composition-level contract, so a collision is a misconfiguration.
     * @param route - kind, path, and the owning handler.
     * @returns the disposer removing the route.
     */
    register(route: WebRoute): () => void;
    /**
     * Register an exact-path upgrade route. The desktop surface never upgrades a
     * socket — event streams ride IPC directly — so registrations are held for
     * structural parity with the web carrier and never dispatched.
     * @param route - pathname and handler.
     * @returns the disposer removing the route.
     */
    registerUpgrade(route: WebUpgradeRoute): () => void;
    /**
     * Claim the fallback seat: the handler answering every request no named
     * route matches (the SPA dist server in the shipped composition). One owner
     * only.
     * @param handler - owns the full response lifecycle of unmatched requests.
     * @returns the disposer releasing the seat.
     */
    registerFallback(handler: WebRoute['handler']): () => void;
    /**
     * Register an index.html transform, applied to every index response in
     * registration order.
     * @param transform - pure html-to-html function.
     * @returns the disposer removing the transform.
     */
    tapIndex(transform: (html: string) => string): () => void;
    /**
     * Run an index.html body through the registered taps in registration order
     * — called by the fallback owner on every index response it renders.
     * @param html - the raw index.html body.
     * @returns the transformed body.
     */
    applyIndexTaps(html: string): string;
    /**
     * Gather the structured injection table: one `webserver/index-inject` emit,
     * every subscriber pushes its current rows. Fresh per call, so subscribers
     * read live state at emit time. Mirrors the web carrier so the same
     * frontend plugin renders identically over either transport.
     * @returns rows in subscriber activation order.
     */
    collectIndexInjections(): IndexInjection[];
    /**
     * Render one index.html body: the structured injection table first, then
     * the raw `tapIndex` transforms over the result.
     * @param html - the raw index.html body.
     * @returns the transformed body.
     */
    renderIndex(html: string): string;
    /**
     * Dispatch one protocol request through the route tables and the fallback
     * seat — the app:// protocol handler's entry point. The handler receives a
     * node:http-shaped request/response pair; the shims collect the written
     * status, headers, and body into a plain `Response`.
     * @param request - the protocol Request (any URL; the pathname routes).
     * @returns the collected Response (404 when no route or fallback exists).
     */
    dispatch(request: Request): Promise<Response>;
    /** Longest-prefix-wins over the prefix table after an exact-table miss. */
    private match;
}
export default DesktopWebServer;
//# sourceMappingURL=index.d.ts.map