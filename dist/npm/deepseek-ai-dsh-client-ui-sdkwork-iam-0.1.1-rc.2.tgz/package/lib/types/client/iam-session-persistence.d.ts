/**
 * Durable IAM session helpers for browser restarts: the auth stack validates
 * stored dual-token sessions against `sessions.current.retrieve`, but a failed
 * validation clears localStorage even when the failure is transient. These
 * helpers mirror the sdkwork auth runtime's stored-session rules so ui-sdkwork-iam
 * can hydrate credentials and restore a backed-up session after bootstrap.
 */
import type { SdkworkAuthSession } from '@sdkwork/auth-pc-react';
import type { IamStoredSession } from './iam-token-store.ts';
/** Persisted session blob including optional identity fields for fast UI restore. */
export interface IamPersistedSession extends IamStoredSession {
    context?: unknown;
    sessionId?: string;
}
/**
 * Whether the stored blob carries a complete, unexpired dual-token session.
 * @param session - raw localStorage snapshot.
 * @returns true when bootstrap may treat the blob as a signed-in session.
 */
export declare function isPersistableStoredSession(session: IamStoredSession): session is IamPersistedSession;
/**
 * Project a persisted blob onto the controller session shape.
 * @param stored - complete stored session.
 * @returns the session for {@link SdkworkAuthController.applySession}, or null.
 */
export declare function toRestoredAuthSession(stored: IamPersistedSession): SdkworkAuthSession | null;
//# sourceMappingURL=iam-session-persistence.d.ts.map