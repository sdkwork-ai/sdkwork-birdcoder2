/** ui-sdkwork-iam dictionaries: the account mode, its rail entry, and the surfaces. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'page.title': string;
    'page.unconfigured.title': string;
    'page.unconfigured.detail': string;
    'page.signedOut.title': string;
    'page.signedOut.detail': string;
    'modal.close': string;
    'account.username': string;
    'account.id': string;
    'account.email': string;
    'account.signOut': string;
};
/** The ui-sdkwork-iam namespace key union. */
export type UiIamKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'page.title': string;
    'page.unconfigured.title': string;
    'page.unconfigured.detail': string;
    'page.signedOut.title': string;
    'page.signedOut.detail': string;
    'modal.close': string;
    'account.username': string;
    'account.id': string;
    'account.email': string;
    'account.signOut': string;
};
//# sourceMappingURL=locales.d.ts.map