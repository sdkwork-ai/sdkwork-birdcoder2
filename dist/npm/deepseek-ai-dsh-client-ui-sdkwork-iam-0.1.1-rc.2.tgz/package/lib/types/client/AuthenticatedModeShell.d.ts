/**
 * Signed-out shell for SDKWork-backed mode pages: opens the modal sign-in
 * overlay when the page first mounts unsigned, keeps a retry CTA after the
 * user dismisses the overlay, and mounts children only after IAM reports
 * signed in so those surfaces never run anonymous SDK traffic.
 */
import { type ReactNode } from 'react';
import type { AuthenticatedModeGate } from './authenticated-mode.ts';
/** Props of the signed-out / signed-in page wrapper. */
export interface AuthenticatedModeShellProps {
    /** Live IAM session face (isSignedIn + overlay + subscribe). */
    gate: AuthenticatedModeGate;
    /** Heading shown while signed out. */
    title: string;
    /** Supporting copy shown while signed out. */
    detail: string;
    /** Label of the retry sign-in button. */
    actionLabel: string;
    /** The SDKWork page to mount after sign-in. */
    children: ReactNode;
}
/**
 * Render children while signed in; otherwise the signed-out notice and a
 * button that re-opens the overlay.
 * @param props - gate, copy, and the authenticated page tree.
 * @returns the signed-in children or the signed-out notice.
 */
export declare function AuthenticatedModeShell({ gate, title, detail, actionLabel, children, }: AuthenticatedModeShellProps): string | number | bigint | boolean | import("react/jsx-runtime").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined;
//# sourceMappingURL=AuthenticatedModeShell.d.ts.map