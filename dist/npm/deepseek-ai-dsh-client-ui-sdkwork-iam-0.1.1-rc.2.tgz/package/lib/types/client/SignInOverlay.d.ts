import { type SdkworkAuthController } from '@sdkwork/auth-pc-react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { ThemeSnapshot } from '@deepseek-ai/dsh-client-ui-theme/client';
import type { createIamUiStore } from './iam-ui-store.ts';
/** Injected business face: the auth controller, the dismiss gesture, locale, config. */
export interface SignInOverlayInjected {
    /** The auth controller driving the modal. */
    controller: SdkworkAuthController;
    /** Close the modal (auth complete or dismiss). */
    onClose: () => void;
    /** The harness locale id mapped to the sdkwork tag. */
    locale: string;
    hooks: {
        /** Whether the IAM base URL is configured (false renders the notice). */
        configured: HostObservable<boolean>;
        /** The resolved harness theme snapshot feeding the sdkwork appearance. */
        theme: HostObservable<ThemeSnapshot>;
    };
}
/** Full component props: overlay owner share + store + injected face + locale seat. */
export type SignInOverlayProps = PropsRuntime<'shell.overlay'> & PropsStore<ReturnType<typeof createIamUiStore>> & InjectFace<SignInOverlayInjected> & PropsLocale<'uiIam'>;
/**
 * Render the modal sign-in surface while the store says it is open.
 * @param props - composed slot props (store share + injected face + locale seat).
 * @returns the modal element tree, or null while closed.
 */
export declare function SignInOverlay(props: SignInOverlayProps): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=SignInOverlay.d.ts.map