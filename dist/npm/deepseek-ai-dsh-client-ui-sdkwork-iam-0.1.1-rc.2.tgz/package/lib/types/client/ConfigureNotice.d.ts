/** The dictionary keys the notice reads. */
export type ConfigureNoticeCopyKey = 'page.unconfigured.title' | 'page.unconfigured.detail';
/** Props of the shared notice. */
export interface ConfigureNoticeProps {
    /** The uiIam dictionary seat (keys `page.unconfigured.title/detail`). */
    t: (key: ConfigureNoticeCopyKey) => string;
    /** The dialog shell's label target when rendered inside a dialog. */
    titleId?: string;
}
/**
 * Render the unconfigured notice.
 * @param props - the dictionary seat and optional dialog label target.
 * @returns the notice element tree.
 */
export declare function ConfigureNotice({ t, titleId }: ConfigureNoticeProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ConfigureNotice.d.ts.map