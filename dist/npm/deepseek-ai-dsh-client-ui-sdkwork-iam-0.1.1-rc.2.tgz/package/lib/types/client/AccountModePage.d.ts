import { type SdkworkAuthController, type SdkworkAuthControllerState, type SdkworkAuthRuntimeConfig } from '@sdkwork/auth-pc-react';
import { type HostObservable, type InjectFace, type PropsLocale, type PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ThemeSnapshot } from '@deepseek-ai/dsh-client-ui-theme/client';
/** The sdkwork i18n locale tag for the harness locale id. */
export declare function toSdkworkLocale(locale: string): string;
/** Injected business face: mode id, controller, config, hooks, gestures. */
export interface AccountModePageInjected {
    /** The page's own mode id (the keyed registration's key). */
    mode: 'account';
    /** The auth controller the auth surfaces drive. */
    controller: SdkworkAuthController;
    /** The auth-surface runtime config derived from the live settings. */
    runtimeConfig: SdkworkAuthRuntimeConfig;
    /** The end-session gesture. */
    onSignOut: () => void;
    /** The harness locale id mapped to the sdkwork tag. */
    locale: string;
    hooks: {
        /** Whether the IAM base URL is configured (false renders the notice). */
        available: HostObservable<boolean>;
        /** The live controller state feeding the page's three branches. */
        authState: HostObservable<SdkworkAuthControllerState>;
        /** The resolved harness theme snapshot feeding the sdkwork appearance. */
        theme: HostObservable<ThemeSnapshot>;
    };
}
/** Full component props: runtime share + injected face + locale seat. */
export type AccountModePageProps = PropsRuntime<'mode.page'> & InjectFace<AccountModePageInjected> & PropsLocale<'uiIam'>;
/**
 * Render the account mode page.
 * @param props - composed slot props (contract share + injected face + locale seat).
 * @returns the page element tree.
 */
export declare function AccountModePage({ controller, runtimeConfig, useAvailable, useAuthState, useTheme, onSignOut, locale, t, }: AccountModePageProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AccountModePage.d.ts.map