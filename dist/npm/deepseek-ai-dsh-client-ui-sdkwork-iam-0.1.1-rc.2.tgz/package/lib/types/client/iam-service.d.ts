/**
 * The `ctx.iam` service: owns the sdkwork auth controller over the runtime
 * adapter, mirrors the `ui-sdkwork-iam` settings scope, and dispatches the sign-in
 * presentation (modal vs full-page account mode). Cross-plugin consumers use
 * this face; the settings-menu account seam is bound by account-source.ts.
 */
import { type SdkworkAuthController, type SdkworkAuthRuntimeConfig } from '@sdkwork/auth-pc-react';
import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client';
import type { ILayout } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { EnvService } from '@deepseek-ai/dsh-client-ui-sdkwork-env/client';
import { type UiIamSettings } from '../iam-settings.ts';
import { type AuthenticatedModeGate } from './authenticated-mode.ts';
import type { AppModeId } from '@deepseek-ai/dsh-client-ui-layout/client';
/** The modal open/close actions, bound by the overlay registration. */
export interface IamModalActions {
    open: () => void;
    close: () => void;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The IAM service face (auth controller, settings mirror, presentation dispatch). */
        iam: IamService;
    }
}
/**
 * IAM service: controller + settings mirror + sign-in presentation dispatch.
 * The controller is created once; its runtime adapter is (re)built lazily
 * from the shared ui-sdkwork-env profile so an environment switch takes effect
 * without reload.
 */
export declare class IamService implements AuthenticatedModeGate {
    readonly controller: SdkworkAuthController;
    private readonly scope;
    private readonly env;
    private readonly layout;
    private modal;
    private runtime;
    private runtimeBaseUrl;
    private readonly tokenStore;
    private readonly tokenManager;
    constructor(scope: SettingsScope<UiIamSettings>, env: EnvService, layout: ILayout);
    /** The current settings snapshot (schema defaults until the scope resolves). */
    currentSettings(): UiIamSettings;
    /** Whether sign-in is available (the active environment carries a base URL). */
    isConfigured(): boolean;
    /** Whether the IAM controller currently holds a signed-in session. */
    isSignedIn(): boolean;
    /** The active environment's IAM tenant application id. */
    appId(): string;
    /** The auth-surface runtime config derived from the live settings. */
    authRuntimeConfig(): SdkworkAuthRuntimeConfig;
    /** Observe controller and settings changes (components re-read on either). */
    subscribe(listener: () => void): () => void;
    /**
     * The settings-menu sign-in gesture: modal or full-page per the setting.
     * Unconfigured the chosen surface still opens — the modal host and the
     * account page both render the configuration notice instead of the auth
     * surface, so the gesture never silently no-ops.
     */
    openSignIn(): void;
    /**
     * Open the modal sign-in overlay for gated product modes. Settings-menu
     * presentation (`page` vs `modal`) does not apply: those modes stay on
     * screen behind the overlay so login returns to the module the user opened.
     */
    openSignInOverlay(): void;
    /**
     * Switch the frame to `mode` and open the sign-in overlay when that mode
     * requires a session and the user is signed out.
     * @param mode - the rail or layout mode the user requested.
     * @param setMode - the layout store's mode switch.
     */
    requestAuthenticatedMode(mode: AppModeId, setMode: (mode: AppModeId) => void): void;
    /** Close the modal sign-in surface. */
    closeModal(): void;
    /** Adopt the modal open/close actions (overlay registration's bound store). */
    attachModal(actions: IamModalActions): void;
    /**
     * Restore a stored session; no-op while the IAM base URL is unconfigured.
     *
     * The sdkwork auth runtime validates storage through
     * `sessions.current.retrieve` and clears localStorage on any failure. A
     * snapshot taken before validation is written back when validation leaves
     * the controller anonymous so restarts survive transient network faults.
     */
    bootstrap(): Promise<void>;
    /** The lazily built runtime adapter for the active environment. */
    private readRuntime;
    /**
     * Keep the generated SDK client's credential transport in sync.
     *
     * IAM session tokens are the signed-in credentials; a static env access
     * token fills Access-Token when the session omits it and is the anonymous
     * catalog credential when signed out. Membership checkout requires both
     * Access-Token and authToken, so env-only bootstrap must not replace authToken.
     */
    private syncTokenManagerFromEnvOrSession;
    /** Seed transport credentials from durable storage before bootstrap runs. */
    private seedCredentialsFromStorage;
    private readPersistableSession;
    private applyPersistedSession;
    private repersistAndApplySession;
    /**
     * Prefer the live controller session; fall back to durable storage while
     * bootstrap has not yet hydrated the controller.
     */
    private syncTokenManagerFromStoredOrController;
}
//# sourceMappingURL=iam-service.d.ts.map