/**
 * SDKWork IAM integration plugin, browser half: provides the `ctx.iam`
 * service (auth controller over the generated app client + settings mirror
 * + presentation dispatch), binds the settings-menu account seam to the IAM
 * session (`ctx.account.setSource`), registers the account app mode (rail
 * entry + full-page auth page), and hosts the modal sign-in surface on the
 * frame's floating overlay. The `ui-sdkwork-iam` settings scope (base URL, app id,
 * presentation, QR/OAuth toggles) lands from the Host settings document.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type UiIamKey } from './locales.ts';
export { AuthenticatedModeShell, type AuthenticatedModeShellProps } from './AuthenticatedModeShell.tsx';
export { AuthenticatedSdkworkModePage, type AuthenticatedSdkworkModePageInjected, type AuthenticatedSdkworkModePageProps, } from './AuthenticatedSdkworkModePage.tsx';
export { AUTHENTICATED_APP_MODES, injectAuthenticatedModePage, isAuthenticatedAppMode, requestAuthenticatedMode, type AuthenticatedAppModeId, type AuthenticatedModeGate, } from './authenticated-mode.ts';
export { IamService } from './iam-service.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The ui-sdkwork-iam plugin's copy (rail entry, account page, modal host). */
        uiIam: UiIamKey;
    }
}
/** Services required by the ui-sdkwork-iam plugin (cordis fiber inject). */
export declare const inject: string[];
/**
 * Register the ui-sdkwork-iam dictionaries, the IAM service, the account seam
 * binding, the account mode, and the modal host, each once its slot
 * declaration is on the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map