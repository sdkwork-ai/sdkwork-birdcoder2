/**
 * The IAM-backed account source: binds the settings-menu account seam
 * (`ctx.account.setSource`) to the IAM controller state. Snapshot identity
 * follows the controller's state object — a stable reference until the
 * session moves. The source's presence means the ui-sdkwork-iam plugin is active, so
 * the menu advertises the sign-in row while signed out even before the IAM
 * base URL is configured — the modal then opens into the configuration
 * notice instead of a silent no-op.
 */
import type { AccountProfile, AccountSource } from '@deepseek-ai/dsh-client-ui-sdkwork-settings-menu/client';
import type { SdkworkAuthControllerState } from '@sdkwork/auth-pc-react';
import type { IamService } from './iam-service.ts';
/**
 * Project the controller state onto the menu's account profile.
 * @param state - the live controller state.
 * @returns the account profile the menu renders.
 */
export declare function toAccountProfile(state: SdkworkAuthControllerState): AccountProfile;
/**
 * Build the account source the settings menu consumes.
 * @param service - the IAM service face.
 * @returns the source bound through `ctx.account.setSource`.
 */
export declare function createIamAccountSource(service: IamService): AccountSource;
//# sourceMappingURL=account-source.d.ts.map