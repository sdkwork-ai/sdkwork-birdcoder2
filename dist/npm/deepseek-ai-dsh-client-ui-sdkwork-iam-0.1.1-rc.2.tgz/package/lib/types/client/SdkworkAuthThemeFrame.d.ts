/**
 * Scoped theme shell for the sdkwork-iam auth surfaces. Auth CSS and Tailwind
 * `dark:` utilities key off a local `.dark` ancestor and `data-sdk-color-mode`;
 * this frame also mirrors the harness scheme onto `document.documentElement`
 * while mounted so overlay login stays aligned with BirdCoder appearance.
 */
import { type ReactNode } from 'react';
import './sdkwork-auth.module.css';
/** Props for the IAM auth theme shell. */
export interface SdkworkAuthThemeFrameProps {
    /** Resolved harness color scheme. */
    colorScheme: 'light' | 'dark';
    /** Optional `data-sdk-surface` marker for tests. */
    surface?: string;
    /** Auth page, modal, or notice. */
    children: ReactNode;
    /** Extra class names on the shell root. */
    className?: string;
}
/**
 * Wrap IAM auth content so light/dark tokens and Tailwind `dark:` variants
 * follow the harness color scheme.
 * @param props - color scheme, optional surface marker, and children.
 * @returns the themed shell element tree.
 */
export declare function SdkworkAuthThemeFrame({ colorScheme, surface, children, className, }: SdkworkAuthThemeFrameProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SdkworkAuthThemeFrame.d.ts.map