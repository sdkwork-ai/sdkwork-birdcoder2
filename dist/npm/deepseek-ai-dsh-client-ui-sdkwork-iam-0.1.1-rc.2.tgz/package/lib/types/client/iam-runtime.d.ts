/**
 * The sdkwork-iam runtime adapter: the `SdkworkIamRuntimeAuthRuntimeLike`
 * the auth-pc-react controller and surfaces consume, backed directly by the
 * generated `@sdkwork/iam-app-sdk` client. The client unwraps the V3
 * envelope and throws on business-error codes, so the adapter only maps
 * method shapes and keeps the shared token manager in step with the durable
 * token store so the SDK transport always finds current credentials.
 */
import type { AuthTokenManager } from '@sdkwork/sdk-common';
import type { SdkworkIamRuntimeAuthRuntimeLike } from '@sdkwork/auth-pc-react';
import type { IamTokenStore } from './iam-token-store.ts';
export interface CreateIamAuthRuntimeOptions {
    /** The IAM app-api origin (non-empty by the time the runtime is created). */
    baseUrl: string;
    /** The browser-local token store persisting the session across reloads. */
    tokenStore: IamTokenStore;
    /** Shared token manager keeping the SDK client's transport credentials current. */
    tokenManager: AuthTokenManager;
}
/**
 * Build the auth runtime over the generated app client.
 * @param options - base URL, durable token store, and the shared token manager.
 * @returns the runtime shape the sdkwork auth stack consumes.
 */
export declare function createIamAuthRuntime(options: CreateIamAuthRuntimeOptions): SdkworkIamRuntimeAuthRuntimeLike;
//# sourceMappingURL=iam-runtime.d.ts.map