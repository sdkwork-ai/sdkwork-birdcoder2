/**
 * Maps the harness color scheme onto the sdkwork auth appearance presets
 * and overlays harness semantic tokens so the form column follows BirdCoder.
 * Token values are `var(--dsw-alias-*)` references resolved at runtime, so a
 * live theme switch repaints without rebuilding the appearance.
 */
import { type SdkworkAuthAppearanceConfig } from '@sdkwork/auth-pc-react';
/**
 * The sdkwork appearance for one harness color scheme: the matching preset
 * (light `sdkwork`, dark `midnight`) with form-column harness tokens and a
 * QR column that follows the dialog shell.
 * @param colorScheme - the harness theme's resolved color scheme.
 * @returns the sdkwork appearance config.
 */
export declare function sdkworkAuthAppearanceFor(colorScheme: 'light' | 'dark'): SdkworkAuthAppearanceConfig;
//# sourceMappingURL=auth-appearance.d.ts.map