/**
 * Browser-global SDKWork credential transport shared by IAM and every
 * SDKWork-backed client plugin. One {@link AuthTokenManager} keeps login
 * state consistent across Token Plan, Drive, Knowledge, Agents, and Feedback.
 * @module @deepseek-ai/dsh-client-ui-sdkwork-iam/sdkwork-global-token-manager
 */
import { type AuthTokenManager, type AuthTokens } from '@sdkwork/sdk-common';
/** IAM session fields merged into the shared token manager. */
export interface SdkworkHostSessionTokens {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
}
/**
 * Merge IAM session tokens with the env access token the way App Store and
 * Drive hosts do. IAM tokens are the signed-in credentials; a static env
 * access token fills Access-Token when the session omits it and is the
 * anonymous catalog credential when signed out.
 *
 * @param session - current IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token from the active deployment.
 * @returns the credential snapshot for SDKWork clients and session providers.
 */
export declare function mergeSdkworkSessionTokens(session: SdkworkHostSessionTokens | null | undefined, staticAccessToken: string): AuthTokens;
/**
 * Write merged IAM and env credentials into the shared token manager.
 * @param session - current IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token from the active deployment.
 */
export declare function syncSdkworkGlobalTokenManager(session: SdkworkHostSessionTokens | null | undefined, staticAccessToken: string): void;
/**
 * @returns the browser-global SDKWork token manager shared by all plugins.
 */
export declare function getSdkworkGlobalTokenManager(): AuthTokenManager;
/** Clear the browser-global manager so tests can prove isolation. */
export declare function resetSdkworkGlobalTokenManager(): void;
//# sourceMappingURL=sdkwork-global-token-manager.d.ts.map