/** SDKWork IAM integration settings stored in the Host user-settings document. */
import z from '@deepseek-ai/schemastery';
/** Settings namespace owned by the ui-sdkwork-iam plugin. */
export declare const UI_IAM_NAMESPACE = "ui-sdkwork-iam";
/** Field carrying the sign-in presentation in the ui-sdkwork-iam section. */
export declare const UI_IAM_PRESENTATION_FIELD = "presentation";
/** Field carrying the QR-login toggle in the ui-sdkwork-iam section. */
export declare const UI_IAM_QR_LOGIN_FIELD = "qrLoginEnabled";
/** Field carrying the OAuth-login toggle in the ui-sdkwork-iam section. */
export declare const UI_IAM_OAUTH_LOGIN_FIELD = "oauthLoginEnabled";
/** How the settings-menu sign-in gesture presents the auth surface. */
export type UiIamPresentation = 'page' | 'modal';
/**
 * Durable ui-sdkwork-iam section shared by the Host schema and the browser scope.
 * The IAM base URL and tenant application id come from the shared ui-sdkwork-env
 * profile (see @deepseek-ai/dsh-client-ui-sdkwork-env), so a deployment switches
 * environments in one place instead of per-plugin settings.
 */
export interface UiIamSettings {
    /** How the settings-menu sign-in opens: full-page account mode or the modal. */
    presentation: UiIamPresentation;
    /** Whether the auth page offers QR-code login. */
    qrLoginEnabled: boolean;
    /** Whether the auth page offers OAuth provider login. */
    oauthLoginEnabled: boolean;
}
/** Durable ui-sdkwork-iam schema; also the wire envelope the browser scope validates against. */
export declare const UiIamSettingsSchema: z<UiIamSettings>;
/** The schema defaults, for reads before the settings scope resolves. */
export declare const DEFAULT_UI_IAM_SETTINGS: UiIamSettings;
//# sourceMappingURL=iam-settings.d.ts.map