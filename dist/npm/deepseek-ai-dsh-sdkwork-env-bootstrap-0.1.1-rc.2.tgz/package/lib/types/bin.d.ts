#!/usr/bin/env node
/**
 * `dsh-sdkwork-env-bootstrap` — CLI for {@link ensureSdkworkBootstrapToken}:
 * apply the source/dev launch profile (identity keys + gateway + overlay),
 * then ensure the SDKWork profile has a bootstrap access token, generating
 * a disposable local JWT for development (and test with
 * `--allow-test-token-generation`) into the gitignored profile overlay.
 * `pnpm build` and `pnpm desktop:dev` run this so Electron does not have to
 * generate the token through the bundled dynamic import.
 * @module @deepseek-ai/dsh-sdkwork-env-bootstrap/bin
 */
export {};
//# sourceMappingURL=bin.d.ts.map