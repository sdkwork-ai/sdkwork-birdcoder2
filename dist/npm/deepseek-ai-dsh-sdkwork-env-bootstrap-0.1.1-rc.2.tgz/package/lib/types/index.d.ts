/**
 * SDKWork bootstrap env glue for the harness app bins: resolve the deployment
 * profile the launch environment declares, apply the source/dev vs packaged
 * gateway (`pnpm dsh web` / `pnpm desktop:dev` → `api-dev.birdcoder.com`,
 * packaged/npx/container → `api.birdcoder.com`), and ensure a bootstrap
 * access token in the gitignored profile overlay, reusing
 * `@sdkwork/iam-credential-entry` for token generation and env-file parsing.
 * Token generation follows sdkwork-specs `ENVIRONMENT_SPEC.md` section 6.1:
 * development may generate a disposable local JWT, test only with an explicit
 * allowance, and staging/production fail closed to a private secret source.
 * The module never copies JWT creation, manifest identity lookup, env merge,
 * bootstrap env-file parsing, or inline serialization — those stay in the
 * canonical SDKWork package.
 * @module @deepseek-ai/dsh-sdkwork-env-bootstrap
 */
/**
 * The canonical lifecycle environments a deployment profile may name.
 * Mirrors sdkwork-specs `ENVIRONMENT_SPEC.md` section 5.1.
 */
export type SdkworkLifecycleEnvironment = 'development' | 'test' | 'staging' | 'production';
/** One deployment profile resolved from the launch environment. */
export interface SdkworkBootstrapProfile {
    /** Canonical lifecycle environment (aliases `dev`/`prod` normalized). */
    environment: SdkworkLifecycleEnvironment;
    /** Deployment profile, `standalone` or `cloud`. */
    deploymentProfile: 'standalone' | 'cloud';
    /** Exact two-segment profile id, e.g. `standalone.test`. */
    profileId: string;
}
/** Options for {@link ensureSdkworkBootstrapToken}. */
export interface EnsureSdkworkBootstrapTokenOptions {
    /** Repository root whose `sdkwork.app.config.json` and overlays resolve against; defaults to `process.cwd()`. */
    cwd?: string;
    /** The launch environment (already layered with `.env` values); defaults to `process.env`. */
    env?: Readonly<Record<string, string | undefined>>;
    /** Allow generating a disposable local JWT for the test tier (section 6.1). */
    allowTestTokenGeneration?: boolean;
    /**
     * When no local fixture or registration output exists, attempt IAM
     * application bootstrap (register → provision → enable → access credential)
     * using bootstrap auth credentials from the environment or
     * `~/.sdkwork/iam-bootstrap/` (legacy fallback: `~/.sdkwork/users/`).
     */
    tryApplicationBootstrap?: boolean;
    /** Sink for one-line diagnostics; defaults to stderr. */
    warn?: (line: string) => void;
}
/** The observed outcome of one {@link ensureSdkworkBootstrapToken} run. */
export type EnsureSdkworkBootstrapTokenResult = {
    status: 'unconfigured';
} | {
    status: 'configured';
} | {
    status: 'registered';
    token: string;
} | {
    status: 'generated';
    path: string;
    token: string;
} | {
    status: 'unavailable';
    reason: string;
};
/**
 * Copy a generated or registered bootstrap token into the launch environment
 * before {@link createLaunchEnvironmentSnapshot} / `loadLayeredEnv`, so the
 * ui-sdkwork-env host projection can resolve `SDKWORK_ACCESS_TOKEN` synchronously.
 * @param result - the outcome of {@link ensureSdkworkBootstrapToken}.
 * @param env - the mutable launch environment; defaults to `process.env`.
 */
export declare function materializeEnsuredBootstrapAccessToken(result: EnsureSdkworkBootstrapTokenResult, env?: Record<string, string | undefined>): void;
/** File name (repo root) of the IAM application-bootstrap registration output. */
export declare const REGISTERED_ENV_FILE = ".sdkwork.local.env";
/** Tracked development env materialization at the repository root. */
export declare const SDKWORK_DEVELOPMENT_ENV_FILE = ".env.standalone.development";
/** Development platform API gateway origin (`api-<tier>.birdcoder.com` off production). */
export declare const SDKWORK_DEVELOPMENT_GATEWAY_URL = "http://api-dev.birdcoder.com";
/** Test platform API gateway origin (`api-<tier>.birdcoder.com` off production). */
export declare const SDKWORK_TEST_GATEWAY_URL = "https://api-test.birdcoder.com";
/** Staging platform API gateway origin (`api-<tier>.birdcoder.com` off production). */
export declare const SDKWORK_STAGING_GATEWAY_URL = "https://api-staging.birdcoder.com";
/** Production platform API gateway origin (bare `api.birdcoder.com`). */
export declare const SDKWORK_PRODUCTION_GATEWAY_URL = "https://api.birdcoder.com";
/** Launch profile selecting the SDKWork gateway origin. */
export type SdkworkLaunchProfile = SdkworkLifecycleEnvironment;
/** Options for {@link applySdkworkLaunchEnv}. */
export interface ApplySdkworkLaunchEnvOptions {
    /** Invoking directory (`apps/desktop` or a nested cwd in source `dsh web`; the user home when packaged). */
    cwd: string;
    /** Source/dev launches are `development`; packaged/npx/container launches are `production`. */
    profile: SdkworkLaunchProfile;
    /** Mutable launch environment; defaults to `process.env`. */
    env?: Record<string, string | undefined>;
    /** Sink for one-line diagnostics; defaults to stderr. */
    warn?: (line: string) => void;
}
/** Result of {@link applySdkworkLaunchEnv}. */
export interface AppliedSdkworkLaunchEnv {
    /**
     * Directory whose `.env` is the project layer: the repository root for
     * development (walked up from a nested cwd), the invoking directory for production.
     */
    cwd: string;
}
/**
 * The gitignored overlay that receives a generated bootstrap token for one
 * profile (`ENVIRONMENT_SPEC.md` section 5.1.7).
 * @param cwd - the repository root.
 * @param environment - the canonical lifecycle environment.
 * @returns the absolute overlay path.
 */
export declare function bootstrapLocalEnvPath(cwd: string, environment: string): string;
/**
 * The tracked materialized env file for one lifecycle environment.
 * @param cwd - the repository root.
 * @param environment - the canonical lifecycle environment.
 * @returns the absolute materialized env path.
 */
export declare function trackedSdkworkEnvPath(cwd: string, environment: SdkworkLifecycleEnvironment): string;
/**
 * Resolve the deployment profile the launch environment declares, preferring
 * the exact profile id and falling back to the deployment/environment pair.
 * @param env - the launch environment.
 * @returns the resolved profile, or `undefined` when no SDKWork identity key is set.
 */
export declare function resolveSdkworkBootstrapProfile(env: Readonly<Record<string, string | undefined>>): SdkworkBootstrapProfile | undefined;
/**
 * Walk upward from the invoking directory to the repository root that owns the
 * SDKWork manifest, so launchers invoked from a subdirectory (`apps/cli`,
 * `apps/desktop`) resolve the same overlays. Directory discovery only — manifest
 * content stays with `@sdkwork/iam-credential-entry`.
 * @param start - the invoking directory.
 * @returns the nearest ancestor containing `sdkwork.app.config.json`, or `start` when none exists.
 */
export declare function resolveSdkworkRepoRoot(start: string): string;
/**
 * Choose the SDKWork gateway profile for a source-aware launcher.
 * A directory tree that contains `sdkwork.app.config.json` is a source
 * checkout (`pnpm dsh web`, `pnpm desktop:dev`) and uses development.
 * Packaged installs, npx, and the container runtime have no such file and
 * use production. The desktop shell still passes an explicit profile because
 * a packaged app may chdir to a homedir that happens to contain a checkout.
 * @param cwd - the invoking directory.
 * @returns `development` inside a source checkout, otherwise `production`.
 */
export declare function resolveSdkworkLaunchProfile(cwd: string): SdkworkLaunchProfile;
/**
 * Fill unset SDKWork identity, gateway URL, and bootstrap-token keys for a
 * launcher. Source launches walk to the repository root, apply the project
 * `.env` when present, then fill remaining SDKWork keys from the tracked
 * materialization for the selected lifecycle environment (falling back to
 * built-in defaults for the same environment). This lets `pnpm dsh web` and
 * `pnpm desktop:dev` honor a repo-root `.env` copied from
 * `.env.standalone.test` or `.env.standalone.production` before the frozen
 * launch snapshot is created. Packaged/npx/container launches still fall back
 * to production defaults when no repository manifest is present. Finally the
 * gitignored overlay for the active lifecycle environment fills a blank
 * `SDKWORK_ACCESS_TOKEN`, so an already-generated JWT reaches the launch
 * snapshot without waiting on `@sdkwork/iam-credential-entry`.
 * Empty placeholder values in tracked files are skipped so a later project
 * `.env` can still supply secrets. Inherited process env values are never
 * replaced except a blank `SDKWORK_ACCESS_TOKEN`, which the overlay may fill.
 * @param options - invoking directory, launch profile, and mutable environment.
 * @returns the directory `loadLayeredEnv` should use as the project layer.
 */
export declare function applySdkworkLaunchEnv(options: ApplySdkworkLaunchEnvOptions): AppliedSdkworkLaunchEnv;
/**
 * Ensure a bootstrap access token exists for the declared profile. An
 * explicitly configured `SDKWORK_ACCESS_TOKEN`, the registration output
 * (`.sdkwork.local.env`), and an existing overlay token win without loading
 * `@sdkwork/iam-credential-entry`; otherwise development generates a
 * disposable local JWT into the gitignored overlay, test requires
 * `allowTestTokenGeneration`, and staging/production fail closed. Failures
 * never throw — the caller continues with interactive IAM login as the
 * credential fallback.
 * @param options - root, environment, and diagnostic inputs.
 * @returns the observed outcome.
 */
export declare function ensureSdkworkBootstrapToken(options?: EnsureSdkworkBootstrapTokenOptions): Promise<EnsureSdkworkBootstrapTokenResult>;
//# sourceMappingURL=index.d.ts.map