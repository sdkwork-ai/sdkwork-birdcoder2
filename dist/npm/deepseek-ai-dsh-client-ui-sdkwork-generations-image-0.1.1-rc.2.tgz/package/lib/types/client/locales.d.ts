/** `generationsImage` namespace dictionaries: the rail entry only. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.image': string;
    'mode.image.label': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
/** The generationsImage namespace key union. */
export type ImageGenerationsKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.image': string;
    'mode.image.label': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
//# sourceMappingURL=locales.d.ts.map