import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business data for the image generation rail entry. */
export interface ImageGenerationsRailEntryInjected {
    /** The keyed mode id owned by this entry. */
    mode: 'image';
}
/** Composed props for the image generation rail entry. */
export type ImageGenerationsRailEntryProps = PropsRuntime<'mode.rail.entry'> & ImageGenerationsRailEntryInjected & PropsLocale<'generationsImage'>;
/**
 * Render the image generation rail button.
 * @param props - mode selection owner data, injected id, and locale seat.
 * @returns the rail button.
 */
export declare function ImageGenerationsRailEntry({ mode, active, setMode, t }: ImageGenerationsRailEntryProps): import("react").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map