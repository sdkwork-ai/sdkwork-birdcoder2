/**
 * Self-contained 24px glyphs for the image generation mode, in two weights:
 * the outline set (stroke) for the idle rail entry and the filled set (solid)
 * for the rail's active entry. They follow the shared icon contract
 * ({size, className}, color rides currentColor).
 */
import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Image generation mode, outline: picture frame with sun and mountains. */
export declare const ImageGenIcon: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Image generation mode, filled: solid frame with sun and mountain silhouettes knocked out. */
export declare const ImageGenIconFilled: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
//# sourceMappingURL=icons.d.ts.map