/**
 * Course mode plugin, browser half: registers its rail entry into the keyed
 * `mode.rail.entry` seat (declared by ui-sdkwork-app-modes' rail shell) and its
 * SDKWork-backed page into the keyed `mode.page` seat (declared by
 * ui-layout's frame), both keyed by the `course` mode id. The host adapter is
 * configured from the shared environment, IAM, locale, and theme services before the
 * page can mount.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { EnvService } from '@deepseek-ai/dsh-client-ui-sdkwork-env/client';
import type { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client';
import type { CourseHostAdapter, CourseHostIam, CourseHostTheme } from './courseHost.ts';
import { type CourseKey } from './locales.ts';
export type { CoursePageInjected, CoursePageProps, } from './CoursePage.tsx';
export type { CourseRailEntryInjected, CourseRailEntryProps, } from './RailEntry.tsx';
export type { CourseKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Course mode's copy (rail entry + page). */
        course: CourseKey;
    }
}
/** Services required by the Course mode plugin. */
export declare const inject: string[];
/**
 * Configure the SDKWork host adapter through an injectable test seam.
 * @param env - active BirdCoder deployment environment service.
 * @param iam - active BirdCoder IAM session provider.
 * @param locale - BirdCoder locale runtime.
 * @param theme - BirdCoder theme runtime bridge.
 * @returns Configured SDKWork host adapter and its disposer.
 */
export declare function createCourseAdapter(env: EnvService, iam: CourseHostIam, locale: LocaleRuntime, theme: CourseHostTheme): CourseHostAdapter;
/**
 * Register the Course host adapter, rail entry, and page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map