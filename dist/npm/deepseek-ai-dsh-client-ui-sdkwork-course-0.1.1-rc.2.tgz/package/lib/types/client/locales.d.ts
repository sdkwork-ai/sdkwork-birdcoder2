/** `course` namespace dictionaries: the rail entry and page copy. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.course': string;
    'mode.course.label': string;
    'page.placeholder': string;
    'page.back': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
/** The course namespace key union. */
export type CourseKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.course': string;
    'mode.course.label': string;
    'page.placeholder': string;
    'page.back': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
//# sourceMappingURL=locales.d.ts.map