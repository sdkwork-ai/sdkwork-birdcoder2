import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business face: this entry's mode id (the keyed registration's key). */
export interface CourseRailEntryInjected {
    /** The entry's own mode id. */
    mode: 'course';
}
/** Full component props: runtime share (owner + standard) + injected mode + locale seat. */
export type CourseRailEntryProps = PropsRuntime<'mode.rail.entry'> & CourseRailEntryInjected & PropsLocale<'course'>;
/**
 * Render the Course rail entry cell.
 * @param props - composed slot props (owner share + injected mode + locale seat).
 * @returns the entry button element tree.
 */
export declare function CourseRailEntry({ mode, active, setMode, t }: CourseRailEntryProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map