/**
 * Self-contained 24px Course glyphs in two weights for the mode rail.
 */
import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Course mode, outline: open book with a play badge. */
export declare const CourseIcon: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
/** Course mode, filled: solid book with a play triangle. */
export declare const CourseIconFilled: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=icons.d.ts.map