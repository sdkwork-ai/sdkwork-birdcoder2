/**
 * BirdCoder host adapter for the SDKWork Course PC surface.
 *
 * The adapter owns generated client construction and maps the shared ui-sdkwork-env and
 * ui-sdkwork-iam services to SDKWork's host ports. The embedded view is remounted when
 * the API environment changes; IAM and locale changes flow through the ports.
 */
import { type ReactNode } from 'react';
import '../../../../../../sdkwork-course/apps/sdkwork-course-pc/src/index.css';
import { type CoursePcSdkPorts } from '@sdkwork/course-pc-course';
/** Session user fields forwarded to the SDKWork Course runtime. */
export interface CourseHostSessionUser {
    displayName?: string;
    nickname?: string;
    name?: string;
    avatar?: string;
}
/** Session data supplied to the SDKWork Course runtime. */
export interface CourseHostSessionSnapshot {
    user?: CourseHostSessionUser;
}
/** Environment values consumed by the SDKWork host adapter. */
export interface CourseHostEnvironment {
    /** @returns the active API gateway origin. */
    apiBaseUrl(): string;
    /** @returns the configured static access token, if any. */
    accessToken(): string;
    /** Observe profile or active-environment changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal IAM controller state consumed by the adapter. */
export interface CourseHostIam {
    controller: {
        /** @returns the current session, when authenticated. */
        getState(): {
            session: CourseHostSession | null;
        };
        /** Observe login, refresh, and sign-out changes. */
        subscribe(listener: () => void): () => void;
    };
}
/** Minimal locale runtime consumed by the adapter. */
export interface CourseHostLocale {
    /** @returns the active BirdCoder locale id. */
    getSnapshot(): {
        active: string;
    };
    /** Observe active-locale changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal theme runtime consumed by the adapter. */
export interface CourseHostTheme {
    /** @returns the resolved host color scheme for the embedded Course surface. */
    getColorScheme(): 'light' | 'dark';
    /** Observe resolved color-scheme changes. */
    subscribe(listener: () => void): () => void;
}
/** IAM session fields accepted by the SDKWork Course session bridge. */
export interface CourseHostSession {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
    user?: {
        id?: string;
        displayName?: string;
        email?: string;
        avatar?: unknown;
    };
}
/** Dependencies used to configure the SDKWork surface. */
export interface ConfigureCourseHostOptions {
    env: CourseHostEnvironment;
    iam: CourseHostIam;
    locale: CourseHostLocale;
    theme: CourseHostTheme;
}
/**
 * Convert the host IAM state into SDKWork's session format.
 * @param session - current host IAM session, or null when signed out.
 * @returns a user snapshot, or null when no profile is available.
 */
export declare function toCourseSession(session: CourseHostSession | null): CourseHostSessionSnapshot | null;
/** Lifecycle handle returned after configuring the SDKWork host. */
export interface CourseHostAdapter {
    /** Dispose environment and IAM subscriptions. */
    dispose(): void;
}
/** Observable host-adapter operations used by focused integration tests. */
export interface CourseHostRuntime extends CourseHostAdapter {
    /** Start environment and IAM subscriptions. */
    start(): () => void;
    /** Register a listener for adapter changes. */
    subscribe(listener: () => void): () => void;
    /** @returns the revision used to remount after an environment switch. */
    getEnvironmentRevision(): number;
    /** @returns the current host session for the SDKWork session store. */
    readHostSession(): CourseHostSessionSnapshot | null;
    /** @returns the active SDKWork locale tag. */
    resolveHostLanguage(): string;
    /** Subscribe SDKWork to host locale changes. */
    subscribeHostLanguage(listener: (language: string) => void): () => void;
    /** @returns the SDKWork ports wired for focused integration tests. */
    ports(): CoursePcSdkPorts;
}
/** Configure the global SDKWork runtime ports for the embedded Course surface. */
export declare function configureCourseHost(options: ConfigureCourseHostOptions): CourseHostAdapter;
/** Build an unconfigured adapter for focused host-bridge tests. */
export declare function createCourseHostRuntime(options: ConfigureCourseHostOptions): CourseHostRuntime;
/** Render the SDKWork Course surface through the configured host adapter. */
export declare function CourseApp(): ReactNode;
//# sourceMappingURL=courseHost.d.ts.map