/**
 * The Course page: the center-column surface for the `course` mode, keyed into
 * the frame's `mode.page` slot. Mounts the SDKWork Course PC surface through
 * this plugin's host adapter after IAM reports signed in.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type AuthenticatedSdkworkModePageInjected } from '@deepseek-ai/dsh-client-ui-sdkwork-iam/client';
/** Injected business face: which mode this keyed entry renders. */
export interface CoursePageInjected extends AuthenticatedSdkworkModePageInjected {
    /** The page's own mode id (the keyed registration's key). */
    mode: 'course';
}
/** Full component props: runtime share + injected mode + the locale seat. */
export type CoursePageProps = PropsRuntime<'mode.page'> & CoursePageInjected & PropsLocale<'course'>;
/**
 * Render the Course page.
 * @param props - composed slot props (contract share + injected mode + locale seat).
 * @returns the page element tree.
 */
export declare function CoursePage({ mode, authGate, t }: CoursePageProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CoursePage.d.ts.map