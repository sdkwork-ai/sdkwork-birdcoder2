import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** App Store mode, outline: four-square application grid. */
export declare const AppStoreIcon: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
/** App Store mode, filled: solid four-square grid. */
export declare const AppStoreIconFilled: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=icons.d.ts.map