/**
 * The App Store page: the center-column surface for the `appstore` mode, keyed
 * into the frame's `mode.page` slot. Mounts the SDKWork App Store PC surface
 * through this plugin's host adapter after IAM reports signed in.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type AuthenticatedSdkworkModePageInjected } from '@deepseek-ai/dsh-client-ui-sdkwork-iam/client';
/** Injected business face: which mode this keyed entry renders. */
export interface AppStorePageInjected extends AuthenticatedSdkworkModePageInjected {
    /** The page's own mode id (the keyed registration's key). */
    mode: 'appstore';
}
/** Full component props: runtime share + injected mode + the locale seat. */
export type AppStorePageProps = PropsRuntime<'mode.page'> & AppStorePageInjected & PropsLocale<'appstore'>;
/**
 * Render the App Store page.
 * @param props - composed slot props (contract share + injected mode + locale seat).
 * @returns the page element tree.
 */
export declare function AppStorePage({ mode, authGate, t }: AppStorePageProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AppStorePage.d.ts.map