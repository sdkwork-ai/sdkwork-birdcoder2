/** `appstore` namespace dictionaries: the rail entry copy. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.appstore': string;
    'mode.appstore.label': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
/** The appstore namespace key union. */
export type AppStoreKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.appstore': string;
    'mode.appstore.label': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
//# sourceMappingURL=locales.d.ts.map