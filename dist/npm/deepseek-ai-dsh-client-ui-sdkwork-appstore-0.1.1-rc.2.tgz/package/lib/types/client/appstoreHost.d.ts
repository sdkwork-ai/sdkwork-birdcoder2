/**
 * BirdCoder host adapter for the SDKWork App Store PC surface.
 *
 * The adapter maps the shared ui-sdkwork-env, ui-sdkwork-iam, and locale services to the
 * embeddable `@sdkwork/appstore-pc-host` inputs. Environment changes remount
 * the SDKWork runtime; IAM and locale changes propagate through host props.
 */
import { type ReactNode } from 'react';
import '../../../../../../sdkwork-appstore/apps/sdkwork-appstore-pc/src/index.css';
import { type AppstorePcHostSession } from '@sdkwork/appstore-pc-host';
/** Session data supplied to the SDKWork App Store runtime. */
export type AppstoreHostSessionSnapshot = AppstorePcHostSession;
/** Environment values consumed by the SDKWork host adapter. */
export interface AppstoreHostEnvironment {
    /** @returns the active API gateway origin. */
    apiBaseUrl(): string;
    /** @returns the configured static access token, if any. */
    accessToken(): string;
    /** Observe profile or active-environment changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal IAM controller state consumed by the adapter. */
export interface AppstoreHostIam {
    controller: {
        /** @returns the current session, when authenticated. */
        getState(): {
            session: AppstoreHostSession | null;
        };
        /** Observe login, refresh, and sign-out changes. */
        subscribe(listener: () => void): () => void;
    };
}
/** Minimal locale runtime consumed by the adapter. */
export interface AppstoreHostLocale {
    /** @returns the active BirdCoder locale id. */
    getSnapshot(): {
        active: string;
    };
    /** Observe active-locale changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal theme runtime consumed by the adapter. */
export interface AppstoreHostTheme {
    /** @returns the resolved host color scheme for the embedded App Store surface. */
    getColorScheme(): 'light' | 'dark';
    /** Observe resolved color-scheme changes. */
    subscribe(listener: () => void): () => void;
}
/** IAM session fields accepted by the SDKWork App Store session bridge. */
export interface AppstoreHostSession {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: unknown;
    context?: {
        tenantId?: string;
        userId?: string;
        organizationId?: string | null;
        sessionId?: string;
        appId?: string;
        environment?: string;
        deploymentMode?: string;
        authLevel?: string;
        dataScope?: string[];
        permissionScope?: string[];
        actorId?: string;
        actorKind?: string;
        deviceId?: string;
    };
}
/** Dependencies used to configure the SDKWork surface. */
export interface ConfigureAppstoreHostOptions {
    env: AppstoreHostEnvironment;
    iam: AppstoreHostIam;
    locale: AppstoreHostLocale;
    theme: AppstoreHostTheme;
}
/** Snapshot consumed by the embedded App Store host component. */
export interface AppstoreHostRenderSnapshot {
    environmentRevision: number;
    apiBaseUrl: string;
    accessToken: string;
    locale: string;
    session: AppstoreHostSessionSnapshot | null;
}
/**
 * Convert the host IAM state into SDKWork's session format.
 * Identity fields are derived inside SDKWork App Store from JWT claims; the host
 * forwards credentials only and lets session tokens supersede env bootstrap.
 * @param session - current host IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token used by non-interactive deployments.
 * @returns a credential snapshot, or null when no tokens are available.
 */
export declare function toAppstoreSession(session: AppstoreHostSession | null, staticAccessToken: string): AppstoreHostSessionSnapshot | null;
/** Lifecycle handle returned after configuring the SDKWork host. */
export interface AppstoreHostAdapter {
    /** Dispose environment and IAM subscriptions. */
    dispose(): void;
}
/** Observable host-adapter operations used by focused integration tests. */
export interface AppstoreHostRuntime extends AppstoreHostAdapter {
    /** Start environment and IAM subscriptions. */
    start(): () => void;
    /** Register a listener for adapter changes. */
    subscribe(listener: () => void): () => void;
    /** @returns the revision used to remount after an environment switch. */
    getEnvironmentRevision(): number;
    /** @returns the current host session for the SDKWork session store. */
    readHostSession(): AppstoreHostSessionSnapshot | null;
    /** @returns the active SDKWork locale tag. */
    resolveHostLanguage(): string;
    /** @returns the active host color scheme for the embedded App Store surface. */
    resolveHostColorScheme(): 'light' | 'dark';
    /** Subscribe SDKWork to host color-scheme changes. */
    subscribeHostColorScheme(listener: (scheme: 'light' | 'dark') => void): () => void;
    /** @returns the render snapshot for the embedded host component. */
    getHostSnapshot(): AppstoreHostRenderSnapshot;
}
/** Configure the global SDKWork host adapter for the embedded App Store. */
export declare function configureAppstoreHost(options: ConfigureAppstoreHostOptions): AppstoreHostAdapter;
/** Build an unconfigured adapter for focused host-bridge tests. */
export declare function createAppstoreHostRuntime(options: ConfigureAppstoreHostOptions): AppstoreHostRuntime;
/** Render the SDKWork App Store surface through the configured host adapter. */
export declare function AppstoreApp(): ReactNode;
//# sourceMappingURL=appstoreHost.d.ts.map