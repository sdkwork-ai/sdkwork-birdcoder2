import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business data for the App Store rail entry. */
export interface AppStoreRailEntryInjected {
    /** The keyed mode id owned by this entry. */
    mode: 'appstore';
}
/** Composed props for the App Store rail entry. */
export type AppStoreRailEntryProps = PropsRuntime<'mode.rail.entry'> & AppStoreRailEntryInjected & PropsLocale<'appstore'>;
/**
 * Render the App Store rail button.
 * @param props - mode selection owner data, injected id, and locale seat.
 * @returns the rail button.
 */
export declare function AppStoreRailEntry({ mode, active, setMode, t }: AppStoreRailEntryProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map