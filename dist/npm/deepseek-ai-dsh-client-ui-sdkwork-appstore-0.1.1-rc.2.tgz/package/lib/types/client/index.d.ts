/**
 * App Store mode plugin, browser half: registers its rail entry into the keyed
 * `mode.rail.entry` seat (declared by ui-sdkwork-app-modes' rail shell) and its
 * SDKWork-backed page into the keyed `mode.page` seat (declared by
 * ui-layout's frame), both keyed by the `appstore` mode id. The host adapter
 * is configured from the shared environment, IAM, and locale services before
 * the page can mount.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { EnvService } from '@deepseek-ai/dsh-client-ui-sdkwork-env/client';
import type { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client';
import type { AppstoreHostAdapter, AppstoreHostIam, AppstoreHostTheme } from './appstoreHost.ts';
import { type AppStoreKey } from './locales.ts';
export type { AppStorePageInjected, AppStorePageProps } from './AppStorePage.tsx';
export type { AppStoreRailEntryInjected, AppStoreRailEntryProps } from './RailEntry.tsx';
export type { AppStoreKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The App Store mode's rail copy. */
        appstore: AppStoreKey;
    }
}
/** Services required by the App Store mode plugin. */
export declare const inject: string[];
/**
 * Configure the SDKWork host adapter through an injectable test seam.
 * @param env - active BirdCoder deployment environment service.
 * @param iam - active BirdCoder IAM session provider.
 * @param locale - BirdCoder locale runtime.
 * @returns Configured SDKWork host adapter and its disposer.
 */
export declare function createAppstoreAdapter(env: EnvService, iam: AppstoreHostIam, locale: LocaleRuntime, theme: AppstoreHostTheme): AppstoreHostAdapter;
/**
 * Register the App Store host adapter, rail entry, and page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map