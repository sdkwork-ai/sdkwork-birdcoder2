/**
 * Scoped SDKWork host theme shell: follows the harness color scheme, applies a
 * local `.dark` wrapper for tailwind descendants, and mirrors the scheme onto
 * `document.documentElement` while mounted so legacy SDKWork surfaces that read
 * the root class list stay aligned with BirdCoder appearance settings.
 *
 * Duplicated per SDKWork host adapter package because client-bundle purity
 * forbids cross-plugin value imports from ui-theme.
 */
import { type ReactNode } from 'react';
/** Resolved light/dark scheme for an embedded SDKWork surface. */
export type HostColorScheme = 'light' | 'dark';
/** Minimal host theme face passed into SDKWork host adapters. */
export interface HostThemeBridge {
    /** @returns the resolved host color scheme for the embedded surface. */
    getColorScheme(): HostColorScheme;
    /** Observe resolved color-scheme changes. */
    subscribe(listener: () => void): () => void;
}
/** Props for the embedded SDKWork theme shell. */
export interface SdkworkHostThemeSurfaceProps {
    /** Host theme bridge wired from the plugin apply() theme service. */
    theme: HostThemeBridge;
    /** Optional `data-*` marker for tests and surface-scoped CSS. */
    surface?: string;
    /** Embedded SDKWork body. */
    children?: ReactNode;
    /** Optional extra class names on the shell root. */
    className?: string;
}
/**
 * Render embedded SDKWork content under a host-managed color scheme.
 * @param props - theme bridge, optional surface marker, and children.
 * @returns the themed shell element tree.
 */
export declare function SdkworkHostThemeSurface({ theme, surface, children, className, }: SdkworkHostThemeSurfaceProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=sdkworkHostThemeSurface.d.ts.map