/** Host loader entry for the browser-only App Store mode plugin. */
/** Provides no host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map