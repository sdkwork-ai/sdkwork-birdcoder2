import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type TokenPlanRailEntryInjected } from './RailEntry.tsx';
import { type TokenPlanPageInjected, type TokenPlanTheme } from './TokenPlanPage.tsx';
import { type TokenPlanKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        tokenPlan: TokenPlanKey;
    }
}
export declare const inject: string[];
export type { TokenPlanKey, TokenPlanPageInjected, TokenPlanRailEntryInjected, TokenPlanTheme };
/** Register Token Plan navigation, page, and commerce host dependencies. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map