import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { EnvServiceLike, IamServiceLike } from './token-plan-service.ts';
import './tokenPlan.css';
/** Host color-scheme bridge consumed by the Token Plan page. */
export interface TokenPlanTheme {
    /** @returns the resolved BirdCoder color scheme. */
    getColorScheme(): 'light' | 'dark';
    /** Observe resolved color-scheme changes. */
    subscribe(listener: () => void): () => void;
}
export interface TokenPlanPageInjected {
    mode: 'token-plan';
    env: EnvServiceLike;
    iam: IamServiceLike;
    theme: TokenPlanTheme;
}
export type TokenPlanPageProps = PropsRuntime<'mode.page'> & TokenPlanPageInjected & PropsLocale<'tokenPlan'>;
/**
 * Render the SDKWork membership catalog inside the Agents Token Plan chrome,
 * following the host light/dark scheme through SdkworkThemeProvider.
 * @param props - mode id, environment, IAM, theme, and locale seat.
 * @returns the Token Plan page.
 */
export declare function TokenPlanPage({ mode, env, iam, theme, t }: TokenPlanPageProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TokenPlanPage.d.ts.map