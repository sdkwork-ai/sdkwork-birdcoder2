import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Token Plan outline glyph for idle navigation. */
export declare const TokenPlanIcon: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
/** Token Plan filled glyph for active navigation. */
export declare const TokenPlanIconFilled: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=icons.d.ts.map