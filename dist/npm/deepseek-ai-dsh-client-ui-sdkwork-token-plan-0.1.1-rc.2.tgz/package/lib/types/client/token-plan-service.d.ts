import type { AuthTokens } from '@sdkwork/sdk-common';
import { type SdkworkCouponRechargeService, type SdkworkMembershipCheckoutService, type SdkworkPointsRechargeService } from '@sdkwork/order-service';
/** Minimal environment face consumed across the plugin boundary. */
export interface EnvServiceLike {
    /** @returns whether the active deployment has a usable API origin. */
    isConfigured(): boolean;
    /** @returns the active API gateway origin. */
    apiBaseUrl(): string;
    /** @returns the configured static access token, if any. */
    accessToken(): string;
    /** Observe profile or active-environment changes. */
    subscribe(listener: () => void): () => void;
}
/** IAM session fields Token Plan reads for Membership/Order credentials. */
export interface TokenPlanIamSession {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
}
/** Minimal IAM face consumed across the plugin boundary. */
export interface IamServiceLike {
    controller: {
        getState(): {
            session: TokenPlanIamSession | null;
        };
        subscribe(listener: () => void): () => void;
    };
    openSignIn(): void;
}
/** Runtime commerce services consumed by the Token Plan page. */
export interface TokenPlanCommerce {
    checkout: SdkworkMembershipCheckoutService;
    coupon: SdkworkCouponRechargeService;
    recharge: SdkworkPointsRechargeService;
}
/**
 * Merge IAM session tokens with the env access token the way App Store and Drive do.
 *
 * Membership checkout (`hasSdkworkMembershipSession`) requires both Access-Token
 * and authToken. A static env access token is the anonymous catalog credential
 * and fills Access-Token when a signed-in IAM session omits it. It must not
 * replace `authToken`, or the catalog treats a signed-in user as a guest and
 * plan purchase no-ops because `openSignIn()` returns immediately when IAM is
 * already authenticated.
 *
 * @param session - current IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token from the active deployment.
 * @returns the credential snapshot written to the shared token manager.
 */
export declare function readTokenPlanSessionTokens(session: TokenPlanIamSession | null, staticAccessToken: string): AuthTokens;
/** Whether Membership checkout can run for this credential snapshot.
 * @param tokens - merged IAM and env credentials.
 * @returns true when Access-Token and authToken are both present.
 */
export declare function hasTokenPlanCheckoutSession(tokens: AuthTokens): boolean;
/** Owns SDKWork clients and keeps their shared credentials current. */
export declare class TokenPlanService {
    private readonly env;
    private readonly iam;
    private readonly tokenManager;
    private baseUrl;
    private commerce;
    constructor(env: EnvServiceLike, iam: IamServiceLike);
    /** Whether the active deployment can serve Token Plan requests.
     * @returns Whether the environment has the required API configuration.
     */
    isConfigured(): boolean;
    /** Open BirdCoder's configured sign-in surface. */
    openSignIn(): void;
    /**
     * Whether the catalog may open checkout (dual-token Membership session).
     * @returns true when Access-Token and authToken are both present after merge.
     */
    hasCheckoutSession(): boolean;
    /** Build or return commerce services for the active environment.
     *
     * @returns The shared Membership and Order commerce services.
     */
    readCommerce(): TokenPlanCommerce;
    /** Observe IAM or environment changes and invalidate environment-specific clients.
     * @param listener - Called after credentials or environment state changes.
     * @returns A disposer that removes both subscriptions.
     */
    subscribe(listener: () => void): () => void;
    private readTokens;
    private syncTokens;
}
//# sourceMappingURL=token-plan-service.d.ts.map