import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export interface TokenPlanRailEntryInjected {
    mode: 'token-plan';
}
export type TokenPlanRailEntryProps = PropsRuntime<'mode.rail.entry'> & TokenPlanRailEntryInjected & PropsLocale<'tokenPlan'>;
/** Render the Token Plan entry immediately above the settings seat. */
export declare function TokenPlanRailEntry({ mode, active, setMode, t }: TokenPlanRailEntryProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map