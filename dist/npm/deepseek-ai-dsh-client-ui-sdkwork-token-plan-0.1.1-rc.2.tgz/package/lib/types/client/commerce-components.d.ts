import { type SdkworkSubscriptionCatalogHostComponents } from '@sdkwork/membership-pc-subscription/catalog';
import type { TokenPlanKey } from './locales.ts';
import type { TokenPlanCommerce } from './token-plan-service.ts';
/** Locale lookup used by Token Plan commerce dialogs. */
export type TokenPlanCopy = (key: TokenPlanKey) => string;
export interface TokenPlanCommerceComponentsOptions {
    commerce: TokenPlanCommerce;
    onCompleted: () => Promise<void> | void;
    t: TokenPlanCopy;
}
/**
 * Clear host-component runtime so tests can prove unconfigured access fails.
 * @returns nothing.
 */
export declare function resetTokenPlanCommerceRuntime(): void;
/**
 * Create host modal components backed by Order checkout/recharge and the
 * Agents Token Plan dialog chrome for points details and redemption.
 *
 * Component identities stay stable across locale and commerce refreshes so
 * the checkout dialog does not remount and abort `createPayment`.
 *
 * @param options - commerce ports, completion hook, and locale lookup.
 * @returns catalog host components that replace the Membership placeholders.
 */
export declare function createTokenPlanCommerceComponents({ commerce, onCompleted, t, }: TokenPlanCommerceComponentsOptions): SdkworkSubscriptionCatalogHostComponents;
//# sourceMappingURL=commerce-components.d.ts.map