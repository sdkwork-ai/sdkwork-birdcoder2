/** Host loader entry for the browser-only Token Plan mode plugin. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map