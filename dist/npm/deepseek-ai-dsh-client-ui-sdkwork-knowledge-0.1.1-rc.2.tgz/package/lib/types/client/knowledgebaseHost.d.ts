/**
 * BirdCoder host adapter for the SDKWork Knowledge Base PC surface.
 *
 * The adapter owns generated client construction and maps the shared ui-sdkwork-env and
 * ui-sdkwork-iam services to SDKWork's host ports. The embedded view is remounted when
 * the API environment changes; IAM and locale changes flow through the ports.
 */
import { type ReactNode } from 'react';
import '../../../../../../sdkwork-knowledgebase/apps/sdkwork-knowledgebase-pc/src/index.css';
/** Session data supplied to the SDKWork Knowledge Base runtime. */
export interface KnowledgebaseSessionSnapshot {
    authToken?: string;
    accessToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: {
        id: string;
        displayName?: string;
        avatarUrl?: string;
        email?: string;
    };
    context?: {
        tenantId: string;
        userId: string;
        organizationId?: string;
        sessionId?: string;
        appId?: string;
        environment?: string;
        iamDeploymentMode?: string;
        authLevel?: string;
        dataScope?: string[];
        permissionScope?: string[];
        actorId?: string;
        actorKind?: string;
        deviceId?: string;
    };
}
/** Environment values consumed by the SDKWork host adapter. */
export interface KnowledgebaseHostEnvironment {
    /** @returns the active API gateway origin. */
    apiBaseUrl(): string;
    /** @returns the configured static access token, if any. */
    accessToken(): string;
    /** Observe profile or active-environment changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal IAM controller state consumed by the adapter. */
export interface KnowledgebaseHostIam {
    controller: {
        /** @returns the current session, when authenticated. */
        getState(): {
            session: KnowledgebaseHostSession | null;
        };
        /** Observe login, refresh, and sign-out changes. */
        subscribe(listener: () => void): () => void;
    };
}
/** Minimal locale runtime consumed by the adapter. */
export interface KnowledgebaseHostLocale {
    /** @returns the active BirdCoder locale id. */
    getSnapshot(): {
        active: string;
    };
    /** Observe active-locale changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal theme runtime consumed by the adapter. */
export interface KnowledgebaseHostTheme {
    /** @returns the resolved host color scheme for the embedded Knowledge Base surface. */
    getColorScheme(): 'light' | 'dark';
    /** Observe resolved color-scheme changes. */
    subscribe(listener: () => void): () => void;
}
/** IAM session fields accepted by the SDKWork Knowledge Base session bridge. */
export interface KnowledgebaseHostSession {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: {
        id?: string;
        displayName?: string;
        email?: string;
        avatar?: unknown;
    };
    context?: {
        tenantId?: string;
        userId?: string;
        organizationId?: string | null;
        sessionId?: string;
        appId?: string;
        environment?: string;
        deploymentMode?: string;
        authLevel?: string;
        dataScope?: string[];
        permissionScope?: string[];
        actorId?: string;
        actorKind?: string;
        deviceId?: string;
    };
}
/** Dependencies used to configure the SDKWork surface. */
export interface ConfigureKnowledgebaseHostOptions {
    env: KnowledgebaseHostEnvironment;
    iam: KnowledgebaseHostIam;
    locale: KnowledgebaseHostLocale;
    theme: KnowledgebaseHostTheme;
}
/**
 * Convert the host IAM state into SDKWork's session format.
 * Identity fields are derived inside SDKWork Knowledge Base from JWT claims; the
 * host forwards credentials only and lets session tokens supersede env bootstrap.
 * @param session - current host IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token used by non-interactive deployments.
 * @returns a credential snapshot, or null when no tokens are available.
 */
export declare function toKnowledgebaseSession(session: KnowledgebaseHostSession | null, staticAccessToken: string): KnowledgebaseSessionSnapshot | null;
/** Lifecycle handle returned after configuring the SDKWork host. */
export interface KnowledgebaseHostAdapter {
    /** Dispose environment and IAM subscriptions. */
    dispose(): void;
}
/** Observable host-adapter operations used by focused integration tests. */
export interface KnowledgebaseHostRuntime extends KnowledgebaseHostAdapter {
    /** Start environment and IAM subscriptions. */
    start(): () => void;
    /** Register a listener for adapter changes. */
    subscribe(listener: () => void): () => void;
    /** @returns the revision used to remount after an environment switch. */
    getEnvironmentRevision(): number;
    /** @returns the current host session for the SDKWork session store. */
    readHostSession(): KnowledgebaseSessionSnapshot | null;
    /** @returns the active SDKWork locale tag. */
    resolveHostLanguage(): string;
    /** @returns the active host color scheme for the embedded Knowledge Base surface. */
    resolveHostColorScheme(): 'light' | 'dark';
    /** Subscribe SDKWork to host color-scheme changes. */
    subscribeHostColorScheme(listener: (scheme: 'light' | 'dark') => void): () => void;
    /** Subscribe SDKWork to host locale changes. */
    subscribeHostLanguage(listener: (language: string) => void): () => void;
}
/** Configure the global SDKWork runtime ports for the embedded Knowledge Base. */
export declare function configureKnowledgebaseHost(options: ConfigureKnowledgebaseHostOptions): KnowledgebaseHostAdapter;
/** Build an unconfigured adapter for focused host-bridge tests. */
export declare function createKnowledgebaseHostRuntime(options: ConfigureKnowledgebaseHostOptions): KnowledgebaseHostRuntime;
/** Render the SDKWork Knowledge Base surface through the configured host adapter. */
export declare function KnowledgebaseApp(): ReactNode;
//# sourceMappingURL=knowledgebaseHost.d.ts.map