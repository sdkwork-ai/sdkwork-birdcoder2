/** `knowledge` namespace dictionaries: the rail entry and page copy. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.knowledge': string;
    'mode.knowledge.label': string;
    'page.placeholder': string;
    'page.back': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
/** The knowledge namespace key union. */
export type KnowledgeKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.knowledge': string;
    'mode.knowledge.label': string;
    'page.placeholder': string;
    'page.back': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
//# sourceMappingURL=locales.d.ts.map