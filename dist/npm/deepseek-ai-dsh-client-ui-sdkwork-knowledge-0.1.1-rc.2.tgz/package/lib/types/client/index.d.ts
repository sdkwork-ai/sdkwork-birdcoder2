/**
 * Knowledge Base mode plugin, browser half: registers its rail entry into
 * the keyed `mode.rail.entry` seat (declared by ui-sdkwork-app-modes' rail shell)
 * and its SDKWork-backed page into the keyed `mode.page` seat (declared by
 * ui-layout's frame), both keyed by the `knowledge` mode id. The host adapter
 * is configured from the shared environment, IAM, and locale services before
 * the page can mount.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { EnvService } from '@deepseek-ai/dsh-client-ui-sdkwork-env/client';
import type { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client';
import type { KnowledgebaseHostAdapter, KnowledgebaseHostIam, KnowledgebaseHostTheme } from './knowledgebaseHost.ts';
import { type KnowledgeKey } from './locales.ts';
export type { KnowledgePageInjected, KnowledgePageProps, } from './KnowledgePage.tsx';
export type { KnowledgeRailEntryInjected, KnowledgeRailEntryProps, } from './RailEntry.tsx';
export type { KnowledgeKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Knowledge Base mode's copy (rail entry + page). */
        knowledge: KnowledgeKey;
    }
}
/** Services required by the Knowledge Base mode plugin. */
export declare const inject: string[];
/**
 * Configure the SDKWork host adapter through an injectable test seam.
 * @param env - active BirdCoder deployment environment service.
 * @param iam - active BirdCoder IAM session provider.
 * @param locale - BirdCoder locale runtime.
 * @returns Configured SDKWork host adapter and its disposer.
 */
export declare function createKnowledgebaseAdapter(env: EnvService, iam: KnowledgebaseHostIam, locale: LocaleRuntime, theme: KnowledgebaseHostTheme): KnowledgebaseHostAdapter;
/**
 * Register the Knowledge Base host adapter, rail entry, and page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map