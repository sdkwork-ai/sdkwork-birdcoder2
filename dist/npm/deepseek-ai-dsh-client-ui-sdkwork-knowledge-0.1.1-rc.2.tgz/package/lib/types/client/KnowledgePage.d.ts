/**
 * The Knowledge Base page: the center-column surface for the `knowledge` mode,
 * keyed into the frame's `mode.page` slot. Mounts the SDKWork knowledgebase
 * PC surface through this plugin's host adapter after IAM reports signed in.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type AuthenticatedSdkworkModePageInjected } from '@deepseek-ai/dsh-client-ui-sdkwork-iam/client';
/** Injected business face: which mode this keyed entry renders. */
export interface KnowledgePageInjected extends AuthenticatedSdkworkModePageInjected {
    /** The page's own mode id (the keyed registration's key). */
    mode: 'knowledge';
}
/** Full component props: runtime share + injected mode + the locale seat. */
export type KnowledgePageProps = PropsRuntime<'mode.page'> & KnowledgePageInjected & PropsLocale<'knowledge'>;
/**
 * Render the Knowledge Base page.
 * @param props - composed slot props (contract share + injected mode + locale seat).
 * @returns the page element tree.
 */
export declare function KnowledgePage({ mode, authGate, t }: KnowledgePageProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=KnowledgePage.d.ts.map