import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business face: this entry's mode id (the keyed registration's key). */
export interface KnowledgeRailEntryInjected {
    /** The entry's own mode id. */
    mode: 'knowledge';
}
/** Full component props: runtime share (owner + standard) + injected mode + locale seat. */
export type KnowledgeRailEntryProps = PropsRuntime<'mode.rail.entry'> & KnowledgeRailEntryInjected & PropsLocale<'knowledge'>;
/**
 * Render the Knowledge Base rail entry cell.
 * @param props - composed slot props (owner share + injected mode + locale seat).
 * @returns the entry button element tree.
 */
export declare function KnowledgeRailEntry({ mode, active, setMode, t }: KnowledgeRailEntryProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map