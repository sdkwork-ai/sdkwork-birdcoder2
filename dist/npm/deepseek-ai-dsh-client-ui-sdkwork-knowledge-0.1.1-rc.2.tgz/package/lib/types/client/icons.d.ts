/**
 * Self-contained 24px Knowledge Base glyphs in two weights: the outline set
 * for idle rail entries and the page, the filled set for the rail's active
 * entry. Follows the shared icon contract ({size, className}, color rides
 * currentColor).
 */
import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Knowledge Base mode, outline: open book. */
export declare const KnowledgeIcon: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
/** Knowledge Base mode, filled: solid open book with the spine knocked out. */
export declare const KnowledgeIconFilled: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=icons.d.ts.map