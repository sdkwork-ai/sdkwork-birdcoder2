/**
 * @deepseek-ai/dsh-sdkwork-desktop-app — the desktop bundle's runtime glue plugin plus
 * the bundle patch (`cordis.patch.yml`, declared by the `dsh.bundle.patch`
 * manifest field). The plugin owns the desktop surface: the harness-source
 * section and the desktop-surface prompt section that orients a session run
 * inside the Electron shell (the web bundle's URL-based surface text is
 * disabled by the patch, because a desktop shell has no server URL).
 * @module @deepseek-ai/dsh-sdkwork-desktop-app
 */
import type { Context } from '@deepseek-ai/cordis';
/** Stable Cordis plugin name. */
export declare const name = "sdkwork-desktop-app";
/** Services required before the glue can mount (systemPrompt arrives via ctx.inject). */
export declare const inject: string[];
/**
 * Mount the desktop surface glue: the harness-source section (shared with the
 * web runtime) plus the desktop-surface prompt section.
 * @param ctx - plugin context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map