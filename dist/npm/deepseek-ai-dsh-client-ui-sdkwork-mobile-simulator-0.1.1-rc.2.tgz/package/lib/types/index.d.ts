/** Host loader entry for the mobile simulator plugin. */
/** Provides no host-side behavior (pure presentation client plugin). */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map