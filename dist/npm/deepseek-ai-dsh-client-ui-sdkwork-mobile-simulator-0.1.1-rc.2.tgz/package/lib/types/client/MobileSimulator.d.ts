import type { ReactNode } from 'react';
import { ALL_DEVICES, deviceUserAgent, findDevice, type DeviceSpec } from './devices.ts';
/** Display mode: inline embeds in layout; modal floats over a backdrop. */
export type SimulatorMode = 'inline' | 'modal';
/** Runtime orientation of the simulated screen. */
export type Orientation = 'portrait' | 'landscape';
/** Props shared by both display modes. */
interface SimulatorCoreProps {
    /** The URL to load inside the simulator frame. */
    url: string;
    /** Initial device to simulate; defaults to the first catalog entry. */
    initialDeviceId?: string;
    /** Display mode — inline embeds in layout, modal floats over a backdrop. */
    mode: SimulatorMode;
    /** Initial orientation. */
    initialOrientation?: Orientation;
    /** Whether the device selector toolbar renders. */
    showToolbar?: boolean;
    /** Invoked when the modal requests to close (backdrop click, Esc, close button). */
    onClose?: () => void;
    /** Invoked when the active device changes. */
    onDeviceChange?: (device: DeviceSpec) => void;
    /** Invoked when orientation changes. */
    onOrientationChange?: (orientation: Orientation) => void;
    /** Invoked when the loaded URL changes (user navigated inside the frame). */
    onUrlChange?: (url: string) => void;
    /** Extra class on the outermost simulator node. */
    className?: string;
}
/**
 * The full simulator component — toolbar plus scalable device frame. Handles
 * device switching, orientation, URL navigation, and (in modal mode) the
 * close lifecycle.
 * @param props - see {@link SimulatorCoreProps}.
 * @returns the interactive simulator surface.
 */
export declare function MobileSimulator(props: SimulatorCoreProps): ReactNode;
/** Re-exported types for callers that build on the simulator surface. */
export type { DeviceSpec, SimulatorCoreProps as MobileSimulatorProps };
export { findDevice, deviceUserAgent, ALL_DEVICES };
//# sourceMappingURL=MobileSimulator.d.ts.map