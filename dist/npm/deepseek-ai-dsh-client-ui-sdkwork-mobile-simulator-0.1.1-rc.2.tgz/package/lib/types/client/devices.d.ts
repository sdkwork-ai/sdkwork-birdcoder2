/**
 * Device catalog: canonical mobile devices with their screen specifications,
 * pixel densities, and user-agent strings for emulation. Each device entry
 * captures the physical metrics needed to render an authentic frame and the
 * browser identity needed for user-agent override.
 */
/** Screen notch/cutout style rendered at the top of the device frame. */
export type NotchStyle = 'none' | 'notch' | 'dynamic-island' | 'punch-hole' | 'waterdrop';
/** Physical device frame material/color option. */
export type FrameColor = 'black' | 'white' | 'silver' | 'gold' | 'blue' | 'green' | 'purple' | 'red';
/** Browser engine family used for user-agent generation. */
export type BrowserEngine = 'webkit' | 'blink';
/** A cataloged mobile device with its screen and identity specification. */
export interface DeviceSpec {
    /** Stable device identifier (slug). */
    readonly id: string;
    /** Human-readable device name. */
    readonly name: string;
    /**Device manufacturer/brand. */
    readonly brand: 'Apple' | 'Samsung' | 'Huawei' | 'Xiaomi' | 'OPPO' | 'vivo' | 'Google' | 'OnePlus' | 'Sony' | 'Nokia';
    /** Device product line. */
    readonly line: 'iPhone' | 'Galaxy S' | 'Galaxy A' | 'Galaxy Z' | 'P系列' | 'Mate系列' | 'Mi系列' | 'Pixel' | 'Find X' | 'X系列' | 'Reno' | 'Xperia' | 'Android';
    /** Logical screen width in CSS pixels (portrait). */
    readonly width: number;
    /** Logical screen height in CSS pixels (portrait). */
    readonly height: number;
    /** Device pixel ratio (physical / logical). */
    readonly pixelRatio: number;
    /** Screen notch/cutout style. */
    readonly notch: NotchStyle;
    /** Available frame colors. */
    readonly colors: readonly FrameColor[];
    /** Default frame color. */
    readonly defaultColor: FrameColor;
    /** Touch-screen safe-area insets (px): [top, right, bottom, left]. */
    readonly safeArea: readonly [number, number, number, number];
    /** Physical outline radius (px). */
    readonly radius: number;
    /** Whether the device has a physical.home button. */
    readonly hasHomeButton: boolean;
    /** Device release year (for catalog grouping). */
    readonly year: number;
    /** Engine family used for the user-agent string. */
    readonly engine: BrowserEngine;
    /** Human-readable screen size in inches (optional). */
    readonly screenSize?: string;
}
/** Group label for the device catalog sidebar. */
export type DeviceGroup = 'Apple' | 'Samsung' | 'Huawei' | 'Xiaomi' | 'OPPO' | 'vivo' | 'Google' | 'OnePlus' | 'Other';
/** A labeled group in the device catalog. */
export interface DeviceGroupDef {
    /** Group identifier. */
    readonly id: DeviceGroup;
    /** Display label for the group header. */
    readonly label: string;
    /** Devices in this group, display order. */
    readonly devices: readonly DeviceSpec[];
}
/**
 * Canonical device catalog, grouped by brand. Screen metrics follow Apple's
 * developer documentation and the OEM spec sheets; logical sizes are CSS pixels
 * at the device's native orientation (portrait). Pixel ratios map to the
 * standard DPR tiers each device ships with.
 */
export declare const DEVICE_CATALOG: readonly DeviceGroupDef[];
/** Flattened view of every device in display order. */
export declare const ALL_DEVICES: readonly DeviceSpec[];
/** Look up a device by its stable id; undefined when no device matches. */
export declare function findDevice(id: string): DeviceSpec | undefined;
/**
 * Generate a representative user-agent string for a device. The string follows
 * each engine family's canonical format and the OS version the device ships
 * with; it is suitable for the `navigator.userAgent` override inside the
 * simulator iframe. iOS builds mirror Mobile/15E148-style version tokens;
 * Android builds mirror Chrome-on-Android with the appropriate device tag.
 * @param device - the device to emulate.
 * @returns a user-agent string faithful to the device's identity and engine.
 */
export declare function deviceUserAgent(device: DeviceSpec): string;
/** CSS color value for a frame color token. */
export declare function frameColorValue(color: FrameColor): string;
//# sourceMappingURL=devices.d.ts.map