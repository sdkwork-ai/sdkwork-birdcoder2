import type { ReactNode } from 'react';
/** Props for the modal host. */
export interface ModalProps {
    /** Whether the modal is open. */
    open: boolean;
    /** Invoked when the modal requests to close. */
    onClose: () => void;
    /** Modal body content (typically a `MobileSimulator` in modal mode). */
    children: ReactNode;
    /** Optional override for the backdrop class. */
    backdropClassName?: string;
    /** Optional override for the content class. */
    contentClassName?: string;
    /** Optional aria-label for the dialog. */
    ariaLabel?: string;
    /** Optional test id for the modal root. */
    testId?: string;
}
/**
 * An imperative handle exposing `show`/`close` for callers that prefer a
 * ref-driven lifecycle over declarative `open`. Handled via the native
 * dialog element's `showModal()`/`close()` methods.
 */
export interface ModalHandle {
    /** Present the modal. */
    show: () => void;
    /** Dismiss the modal. */
    close: () => void;
    /** Whether the modal is currently open. */
    isOpen: () => boolean;
}
/**
 * A declarative modal host. Renders its `children` inside a centered content
 * pane; clicks on the backdrop and the Esc key invoke `onClose`. The dialog
 * is mounted only when `open` is true — the modal does not retain hidden
 * state between opens.
 * @param props - modal configuration.
 * @returns the modal element, or null when closed.
 */
export declare function Modal(props: ModalProps): ReactNode;
//# sourceMappingURL=Modal.d.ts.map