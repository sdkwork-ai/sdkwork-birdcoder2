/**
 * Common app-header plugin, browser half: occupies the frame's
 * `shell.app-header` seat with a drag-region title bar for every non-code mode.
 * Code mode keeps the conversation session header; all sidebar-launched modules
 * (video, image, app store, knowledge base, drive, assets, token plan, account)
 * render beneath this bar so desktop window controls no longer overlap content.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type AppHeaderKey } from './locales.ts';
export type { AppHeaderInjected, AppHeaderProps } from './AppHeader.tsx';
export type { AppHeaderKey } from './locales.ts';
export type { AppHeaderMode, AppHeaderPlatform } from './platform.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Shared app-header copy (module titles). */
        appHeader: AppHeaderKey;
    }
    interface SlotMap {
        /**
         * Optional keyed leading chrome per non-code mode (icon, badge). The
         * header dispatches by the active mode id; absent a contribution the seat
         * renders empty and the title stands alone.
         */
        'shell.app-header.leading': {
            kind: 'keyed';
            scope: 'root';
        };
        /**
         * Additive trailing actions beside the window-control spacer (refresh,
         * help, mode-specific utilities).
         */
        'shell.app-header.actions': {
            kind: 'list';
            scope: 'root';
        };
    }
}
/** Services required by the common app-header plugin. */
export declare const inject: string[];
/**
 * Client plugin body: register the shared app header once its slot declaration
 * is on the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map