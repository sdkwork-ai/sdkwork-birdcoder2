import type { AppModeId } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { AppHeaderKey } from './locales.ts';
/** Non-code modes that render beneath the shared app header. */
export type AppHeaderMode = Exclude<AppModeId, 'code'>;
/** Which OS's window-control conventions the header reserves space for. */
export type AppHeaderPlatform = 'win32' | 'darwin' | 'linux' | 'other';
/**
 * Map a Chromium platform identifier to the supported window-control metrics.
 * @param raw - the platform string, e.g. "Win32", "MacIntel", "Linux x86_64".
 * @returns the convention set; unknown strings fall back to the default.
 */
export declare function resolvePlatform(raw: string): AppHeaderPlatform;
/**
 * Resolve the host OS's window-control convention set from Chromium's
 * user-agent platform, falling back to `navigator.platform`.
 * @returns the convention set; unknown or absent platforms fall back to the default.
 */
export declare function platformOf(): AppHeaderPlatform;
/**
 * Resolve the locale key for a mode's title in the shared app header.
 * @param mode - the active non-code mode id.
 * @returns the dictionary key under the `appHeader` namespace.
 */
export declare function titleKeyForMode(mode: AppHeaderMode): AppHeaderKey;
//# sourceMappingURL=platform.d.ts.map