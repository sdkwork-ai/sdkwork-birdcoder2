/** `appHeader` namespace dictionaries: module titles for the shared app header. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.work': string;
    'mode.video': string;
    'mode.image': string;
    'mode.appstore': string;
    'mode.knowledge': string;
    'mode.drive': string;
    'mode.assets': string;
    'mode.account': string;
    'mode.tokenPlan': string;
};
/** The appHeader namespace key union. */
export type AppHeaderKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.work': string;
    'mode.video': string;
    'mode.image': string;
    'mode.appstore': string;
    'mode.knowledge': string;
    'mode.drive': string;
    'mode.assets': string;
    'mode.account': string;
    'mode.tokenPlan': string;
};
//# sourceMappingURL=locales.d.ts.map