/**
 * SDKWork feedback integration plugin, browser half: provides the feedback
 * channel over the appstore feedback collector (`ctx.feedback.setSource` on
 * the settings-menu seam) and hosts the feedback dialog on the frame's
 * floating overlay. The collector base URL, app key, and static access
 * token come from the shared ui-sdkwork-env profile; session tokens flow from the
 * mounted ui-sdkwork-iam controller merged with the env access token through the
 * shared SDKWork token manager. Without either, submissions reach the
 * submissions reach the collector's auth wall and surface its error.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type UiFeedbackKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The ui-sdkwork-feedback plugin's copy (dialog form and states). */
        uiFeedback: UiFeedbackKey;
    }
}
/** Services required by the ui-sdkwork-feedback plugin (cordis fiber inject). */
export declare const inject: string[];
/**
 * Register the ui-sdkwork-feedback dictionaries, the feedback service, the
 * settings-menu seam binding, and the dialog host, each once its slot
 * declaration is on the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map