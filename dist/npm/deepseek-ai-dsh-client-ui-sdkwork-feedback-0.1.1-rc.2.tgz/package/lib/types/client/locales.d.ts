/** ui-sdkwork-feedback dictionaries: the dialog form, its states, and the dialog shell. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'dialog.title': string;
    'dialog.description': string;
    'dialog.close': string;
    'dialog.unconfigured.title': string;
    'dialog.unconfigured.detail': string;
    'dialog.type': string;
    'dialog.type.bug': string;
    'dialog.type.suggestion': string;
    'dialog.type.other': string;
    'dialog.content': string;
    'dialog.content.placeholder': string;
    'dialog.content.required': string;
    'dialog.content.tooLong': string;
    'dialog.contact': string;
    'dialog.contact.placeholder': string;
    'dialog.submit': string;
    'dialog.cancel': string;
    'dialog.submitting': string;
    'dialog.success': string;
    'dialog.error': string;
    'dialog.error.unauthorized': string;
};
/** The ui-sdkwork-feedback namespace key union. */
export type UiFeedbackKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'dialog.title': string;
    'dialog.description': string;
    'dialog.close': string;
    'dialog.unconfigured.title': string;
    'dialog.unconfigured.detail': string;
    'dialog.type': string;
    'dialog.type.bug': string;
    'dialog.type.suggestion': string;
    'dialog.type.other': string;
    'dialog.content': string;
    'dialog.content.placeholder': string;
    'dialog.content.required': string;
    'dialog.content.tooLong': string;
    'dialog.contact': string;
    'dialog.contact.placeholder': string;
    'dialog.submit': string;
    'dialog.cancel': string;
    'dialog.submitting': string;
    'dialog.success': string;
    'dialog.error': string;
    'dialog.error.unauthorized': string;
};
//# sourceMappingURL=locales.d.ts.map