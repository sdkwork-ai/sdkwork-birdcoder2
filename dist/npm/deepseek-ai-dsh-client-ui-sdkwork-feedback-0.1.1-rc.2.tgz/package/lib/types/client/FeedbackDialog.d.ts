import type { HostObservable, InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createFeedbackUiStore } from './feedback-ui-store.ts';
import type { FeedbackService } from './feedback-service.ts';
/** Injected business face: the submission service, the dismiss gesture, config. */
export interface FeedbackDialogInjected {
    /** The feedback service owning submission and presentation dispatch. */
    service: FeedbackService;
    /** Close the dialog (dismiss or successful submission). */
    onClose: () => void;
    hooks: {
        /** Whether the feedback base URL is configured (false renders the notice). */
        configured: HostObservable<boolean>;
    };
}
/** Full component props: overlay owner share + store + injected face + locale seat. */
export type FeedbackDialogProps = PropsRuntime<'shell.overlay'> & PropsStore<ReturnType<typeof createFeedbackUiStore>> & InjectFace<FeedbackDialogInjected> & PropsLocale<'uiFeedback'>;
/**
 * Render the feedback form while the store says it is open.
 * @param props - composed slot props (store share + injected face + locale seat).
 * @returns the dialog element tree, or null while closed.
 */
export declare function FeedbackDialog(props: FeedbackDialogProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=FeedbackDialog.d.ts.map