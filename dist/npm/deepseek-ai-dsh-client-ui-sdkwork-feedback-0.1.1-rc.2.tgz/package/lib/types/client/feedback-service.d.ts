import type { EnvService } from '@deepseek-ai/dsh-client-ui-sdkwork-env/client';
/** One user feedback submission, mirroring the collector's create request. */
export interface FeedbackDraft {
    /** Feedback category the dialog offers (bug / suggestion / other). */
    type: string;
    /** Free-form feedback text; non-blank required by the collector. */
    content: string;
    /** Optional contact channel (email or phone) for follow-up. */
    contact?: string;
}
/** The minimal IAM controller surface the service reads session tokens from. */
export interface IamSessionLike {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
}
/** The minimal IAM service face (`ctx.get('iam')`); absent while ui-sdkwork-iam is unmounted. */
export interface IamServiceLike {
    controller: {
        /** @returns the current auth state carrying the session tokens. */
        getState(): {
            session: IamSessionLike | null;
        };
        /** Observe auth-state changes (login, sign-out, refresh). */
        subscribe(listener: () => void): () => void;
    };
}
/** The dialog open/close actions, bound by the overlay registration. */
export interface FeedbackModalActions {
    open: () => void;
    close: () => void;
}
/**
 * Feedback service: environment mirror + lazily built appstore client +
 * submit + dialog presentation dispatch.
 */
export declare class FeedbackService {
    private readonly env;
    private readonly iam;
    private readonly tokenManager;
    private client;
    private clientBaseUrl;
    private modal;
    private offIam;
    constructor(env: EnvService, iam?: IamServiceLike);
    /** Whether the feedback channel is configured (a non-empty base URL). */
    isConfigured(): boolean;
    /** Adopt the dialog open/close actions (overlay registration's bound store). */
    attachModal(actions: FeedbackModalActions): void;
    /** Open the feedback dialog through the bound overlay actions. */
    open(): void;
    /**
     * Keep the client's tokens in step with the mounted IAM session. The
     * subscription lives for the plugin lifetime; `submit` re-syncs before
     * each request anyway, so a session moving between syncs still sends the
     * current tokens. Env access token supplements IAM Access-Token when the
     * session omits it.
     * @returns the disposer dropping the subscription.
     */
    subscribeIam(): () => void;
    /**
     * Submit feedback to the configured collector.
     * @param draft - the user's feedback (content must be non-blank).
     * @returns a promise resolving on acceptance; rejects with the collector
     * or transport error otherwise.
     */
    submit(draft: FeedbackDraft): Promise<void>;
    /** The lazily built appstore client for the active environment. */
    private readClient;
    /** Copy the current credentials into the shared SDKWork token manager. */
    private syncTokens;
}
//# sourceMappingURL=feedback-service.d.ts.map