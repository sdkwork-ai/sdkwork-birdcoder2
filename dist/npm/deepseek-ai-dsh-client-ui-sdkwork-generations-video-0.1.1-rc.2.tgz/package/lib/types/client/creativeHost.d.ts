/**
 * BirdCoder host adapter for the SDKWork Agents creative (生成) PC surface.
 *
 * The adapter owns generated client construction and maps the shared ui-sdkwork-env and
 * ui-sdkwork-iam services to the Agents PC session store and SDK client providers.
 * The embedded {@link CreativeView} is remounted when the API environment
 * changes; IAM and locale changes flow through the session bridge.
 */
import { type ReactNode } from 'react';
import { type SdkworkChatSession } from '@sdkwork/agents-pc-core/session';
import { type HostThemeBridge } from './sdkworkHostThemeSurface.tsx';
import '../../../../../../sdkwork-agents/apps/sdkwork-agents-pc/src/index.css';
/** Environment values consumed by the SDKWork host adapter. */
export interface CreativeHostEnvironment {
    /** @returns the active API gateway origin. */
    apiBaseUrl(): string;
    /** @returns the configured static access token, if any. */
    accessToken(): string;
    /** @returns the IAM tenant application id for the active profile. */
    appId(): string;
    /** Observe profile or active-environment changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal IAM controller state consumed by the adapter. */
export interface CreativeHostIam {
    controller: {
        /** @returns the current session, when authenticated. */
        getState(): {
            session: CreativeHostSession | null;
        };
        /** Observe login, refresh, and sign-out changes. */
        subscribe(listener: () => void): () => void;
    };
}
/** Minimal locale runtime consumed by the adapter. */
export interface CreativeHostLocale {
    /** @returns the active BirdCoder locale id. */
    getSnapshot(): {
        active: string;
    };
    /** Observe active-locale changes. */
    subscribe(listener: () => void): () => void;
}
/** IAM session fields accepted by the Agents PC session bridge. */
export interface CreativeHostSession {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: {
        id?: string;
        displayName?: string;
        email?: string;
        avatar?: unknown;
    };
    context?: {
        tenantId?: string;
        userId?: string;
        organizationId?: string | null;
        sessionId?: string;
        appId?: string;
        environment?: string;
        deploymentMode?: string;
        authLevel?: string;
        dataScope?: string[];
        permissionScope?: string[];
        actorId?: string;
        actorKind?: string;
        deviceId?: string;
    };
}
/** Minimal theme runtime consumed by the adapter. */
export interface CreativeHostTheme extends HostThemeBridge {
}
/** Dependencies used to configure the SDKWork surface. */
export interface ConfigureCreativeHostOptions {
    env: CreativeHostEnvironment;
    iam: CreativeHostIam;
    locale: CreativeHostLocale;
    theme: CreativeHostTheme;
}
/**
 * Normalize the gateway origin for SDKWork app clients.
 * @param baseUrl - active API gateway origin from ui-sdkwork-env.
 * @returns the gateway root without a duplicated app API suffix.
 */
export declare function normalizeCreativeGatewayBaseUrl(baseUrl: string): string;
/**
 * Convert the host IAM state into the Agents PC session format.
 * Identity fields are resolved inside Agents PC from JWT claims; the host
 * forwards credentials only and lets session tokens supersede env bootstrap.
 * @param session - current host IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token used by non-interactive deployments.
 * @returns a credential snapshot, or null when no tokens are available.
 */
export declare function toCreativeSession(session: CreativeHostSession | null, staticAccessToken: string): SdkworkChatSession | null;
/** Lifecycle handle returned after configuring the SDKWork host. */
export interface CreativeHostAdapter {
    /** Dispose environment and IAM subscriptions. */
    dispose(): void;
}
/** Observable host-adapter operations used by focused integration tests. */
export interface CreativeHostRuntime extends CreativeHostAdapter {
    /** Start environment and IAM subscriptions. */
    start(): () => void;
    /** Register a listener for adapter changes. */
    subscribe(listener: () => void): () => void;
    /** @returns the revision used to remount after an environment switch. */
    getEnvironmentRevision(): number;
    /** @returns the active SDKWork locale tag. */
    resolveHostLanguage(): string;
}
/** Configure the Agents PC SDK providers for the embedded creative surface. */
export declare function configureCreativeHost(options: ConfigureCreativeHostOptions): CreativeHostAdapter;
/** Build an unconfigured adapter for focused host-bridge tests. */
export declare function createCreativeHostRuntime(options: ConfigureCreativeHostOptions): CreativeHostRuntime;
/** Render the SDKWork Agents creative surface through the configured host adapter. */
export declare function CreativeApp(): ReactNode;
//# sourceMappingURL=creativeHost.d.ts.map