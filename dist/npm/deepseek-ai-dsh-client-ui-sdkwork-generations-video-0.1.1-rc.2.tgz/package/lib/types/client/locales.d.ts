/** `generationsVideo` namespace dictionaries: the rail entry and generation page. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.video': string;
    'mode.video.label': string;
    'page.title': string;
    'page.subtitle': string;
    'page.input': string;
    'page.prompt': string;
    'page.prompt.placeholder': string;
    'page.generate': string;
    'page.configure': string;
    'page.generating': string;
    'page.error': string;
    'page.retry': string;
    'page.results': string;
    'page.result': string;
    'page.empty': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
/** The generationsVideo namespace key union. */
export type VideoGenerationsKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.video': string;
    'mode.video.label': string;
    'page.title': string;
    'page.subtitle': string;
    'page.input': string;
    'page.prompt': string;
    'page.prompt.placeholder': string;
    'page.generate': string;
    'page.configure': string;
    'page.generating': string;
    'page.error': string;
    'page.retry': string;
    'page.results': string;
    'page.result': string;
    'page.empty': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
//# sourceMappingURL=locales.d.ts.map