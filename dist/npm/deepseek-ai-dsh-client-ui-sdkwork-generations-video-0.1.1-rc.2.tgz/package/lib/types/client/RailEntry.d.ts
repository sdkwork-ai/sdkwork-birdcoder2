import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business data for the video generation rail entry. */
export interface VideoGenerationsRailEntryInjected {
    /** The keyed mode id owned by this entry. */
    mode: 'video';
}
/** Composed props for the video generation rail entry. */
export type VideoGenerationsRailEntryProps = PropsRuntime<'mode.rail.entry'> & VideoGenerationsRailEntryInjected & PropsLocale<'generationsVideo'>;
/**
 * Render the video generation rail button.
 * @param props - mode selection owner data, injected id, and locale seat.
 * @returns the rail button.
 */
export declare function VideoGenerationsRailEntry({ mode, active, setMode, t }: VideoGenerationsRailEntryProps): import("react").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map