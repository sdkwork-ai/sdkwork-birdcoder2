/**
 * Self-contained 24px glyphs for the video generation mode, in two weights:
 * the outline set (stroke) for the idle rail entry and the filled set (solid)
 * for the rail's active entry. They follow the shared icon contract
 * ({size, className}, color rides currentColor).
 */
import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Video generation mode, outline: play glyph in a rounded frame. */
export declare const VideoGenIcon: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
/** Video generation mode, filled: solid frame with the play glyph knocked out. */
export declare const VideoGenIconFilled: ({ size, className }: ModeIconProps) => import("react").JSX.Element;
//# sourceMappingURL=icons.d.ts.map