/**
 * Video generation mode plugin, browser half: registers its rail entry into
 * the keyed `mode.rail.entry` seat (declared by ui-sdkwork-app-modes' rail shell)
 * and the SDKWork Agents creative (生成) page into the keyed `mode.page` seat
 * (declared by ui-layout's frame), both keyed by the `video` mode id. The
 * host adapter is configured from the shared environment, IAM, and locale
 * services before the embedded {@link CreativeView} can mount.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type VideoGenerationsKey } from './locales.ts';
export type { VideoGenerationsPageInjected, VideoGenerationsPageProps, } from './GenerationsPage.tsx';
export type { VideoGenerationsRailEntryInjected, VideoGenerationsRailEntryProps, } from './RailEntry.tsx';
export type { CreativeHostAdapter, CreativeHostEnvironment, CreativeHostIam, CreativeHostLocale, CreativeHostRuntime, CreativeHostSession, ConfigureCreativeHostOptions, } from './creativeHost.ts';
export type { VideoGenerationsKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The video generation mode's copy (rail entry + page). */
        generationsVideo: VideoGenerationsKey;
    }
}
/** Services required by the video generation mode plugin. */
export declare const inject: string[];
/**
 * Register the creative host adapter, rail entry, and page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map