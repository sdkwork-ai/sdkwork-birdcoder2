/**
 * Self-contained 24px Drive glyphs in two weights: the outline set for idle
 * rail entries and the page, the filled set for the rail's active entry.
 * Follows the shared icon contract ({size, className}, color rides
 * currentColor).
 */
import type { ModeIconProps } from '@deepseek-ai/dsh-client-ui-sdkwork-app-modes/client';
/** Drive mode, outline: cloud drive with the lid line. */
export declare const DriveIcon: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
/** Drive mode, filled: solid cloud with the download arrow knocked out. */
export declare const DriveIconFilled: ({ size, className }: ModeIconProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=icons.d.ts.map