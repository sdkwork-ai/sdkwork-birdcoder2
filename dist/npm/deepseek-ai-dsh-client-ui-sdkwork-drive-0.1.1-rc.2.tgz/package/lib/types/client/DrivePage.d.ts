/**
 * The Drive page: the center-column surface for the `drive` mode, keyed into
 * the frame's `mode.page` slot. Mounts the SDKWork Drive PC surface through
 * this plugin's host adapter after IAM reports signed in.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type AuthenticatedSdkworkModePageInjected } from '@deepseek-ai/dsh-client-ui-sdkwork-iam/client';
/** Injected business face: which mode this keyed entry renders. */
export interface DrivePageInjected extends AuthenticatedSdkworkModePageInjected {
    /** The page's own mode id (the keyed registration's key). */
    mode: 'drive';
}
/** Full component props: runtime share + injected mode + the locale seat. */
export type DrivePageProps = PropsRuntime<'mode.page'> & DrivePageInjected & PropsLocale<'drive'>;
/**
 * Render the Drive page.
 * @param props - composed slot props (contract share + injected mode + locale seat).
 * @returns the page element tree.
 */
export declare function DrivePage({ mode, authGate, t }: DrivePageProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DrivePage.d.ts.map