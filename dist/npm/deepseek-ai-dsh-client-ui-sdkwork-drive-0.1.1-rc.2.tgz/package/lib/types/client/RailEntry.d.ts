import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business face: this entry's mode id (the keyed registration's key). */
export interface DriveRailEntryInjected {
    /** The entry's own mode id. */
    mode: 'drive';
}
/** Full component props: runtime share (owner + standard) + injected mode + locale seat. */
export type DriveRailEntryProps = PropsRuntime<'mode.rail.entry'> & DriveRailEntryInjected & PropsLocale<'drive'>;
/**
 * Render the Drive rail entry cell.
 * @param props - composed slot props (owner share + injected mode + locale seat).
 * @returns the entry button element tree.
 */
export declare function DriveRailEntry({ mode, active, setMode, t }: DriveRailEntryProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RailEntry.d.ts.map