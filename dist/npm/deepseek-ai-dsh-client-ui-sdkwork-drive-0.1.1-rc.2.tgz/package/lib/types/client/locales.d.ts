/** `drive` namespace dictionaries: the rail entry and page copy. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mode.drive': string;
    'mode.drive.label': string;
    'page.placeholder': string;
    'page.back': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
/** The drive namespace key union. */
export type DriveKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mode.drive': string;
    'mode.drive.label': string;
    'page.placeholder': string;
    'page.back': string;
    'auth.required.title': string;
    'auth.required.detail': string;
    'auth.required.action': string;
};
//# sourceMappingURL=locales.d.ts.map