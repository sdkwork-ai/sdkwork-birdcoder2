/**
 * Drive mode plugin, browser half: registers its rail entry into the keyed
 * `mode.rail.entry` seat (declared by ui-sdkwork-app-modes' rail shell) and its
 * SDKWork-backed page into the keyed `mode.page` seat (declared by
 * ui-layout's frame), both keyed by the `drive` mode id. The host adapter is
 * configured from the shared environment, IAM, locale, and theme services before the
 * page can mount.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { EnvService } from '@deepseek-ai/dsh-client-ui-sdkwork-env/client';
import type { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client';
import type { DriveHostAdapter, DriveHostIam, DriveHostTheme } from './driveHost.ts';
import { type DriveKey } from './locales.ts';
export type { DrivePageInjected, DrivePageProps, } from './DrivePage.tsx';
export type { DriveRailEntryInjected, DriveRailEntryProps, } from './RailEntry.tsx';
export type { DriveKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Drive mode's copy (rail entry + page). */
        drive: DriveKey;
    }
}
/** Services required by the Drive mode plugin. */
export declare const inject: string[];
/**
 * Configure the SDKWork host adapter through an injectable test seam.
 * @param env - active BirdCoder deployment environment service.
 * @param iam - active BirdCoder IAM session provider.
 * @param locale - BirdCoder locale runtime.
 * @param theme - BirdCoder theme runtime bridge.
 * @returns Configured SDKWork host adapter and its disposer.
 */
export declare function createDriveAdapter(env: EnvService, iam: DriveHostIam, locale: LocaleRuntime, theme: DriveHostTheme): DriveHostAdapter;
/**
 * Register the Drive host adapter, rail entry, and page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map