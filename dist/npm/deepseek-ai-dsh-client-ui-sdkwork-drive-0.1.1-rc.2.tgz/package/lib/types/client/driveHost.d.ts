/**
 * BirdCoder host adapter for the SDKWork Drive PC surface.
 *
 * The adapter owns generated client construction and maps the shared ui-sdkwork-env and
 * ui-sdkwork-iam services to SDKWork's host ports. The embedded view is remounted when
 * the API environment changes; IAM and locale changes flow through the ports.
 */
import { type ReactNode } from 'react';
import '../../../../../../sdkwork-drive/apps/sdkwork-drive-pc/src/index.css';
/** Session data supplied to the SDKWork Drive runtime. */
export interface DriveSessionSnapshot {
    authToken?: string;
    accessToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: {
        id: string;
        displayName?: string;
        avatarUrl?: string;
        email?: string;
    };
    context?: {
        tenantId: string;
        userId: string;
        organizationId?: string;
        sessionId?: string;
        appId?: string;
        environment?: string;
        deploymentMode?: string;
        authLevel?: string;
        dataScope?: string[];
        permissionScope?: string[];
        actorId?: string;
        actorKind?: string;
        deviceId?: string;
    };
    updatedAt?: string;
}
/** Environment values consumed by the SDKWork host adapter. */
export interface DriveHostEnvironment {
    /** @returns the active API gateway origin. */
    apiBaseUrl(): string;
    /** @returns the configured static access token, if any. */
    accessToken(): string;
    /** Observe profile or active-environment changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal IAM controller state consumed by the adapter. */
export interface DriveHostIam {
    controller: {
        /** @returns the current session, when authenticated. */
        getState(): {
            session: DriveHostSession | null;
        };
        /** Observe login, refresh, and sign-out changes. */
        subscribe(listener: () => void): () => void;
    };
}
/** Minimal locale runtime consumed by the adapter. */
export interface DriveHostLocale {
    /** @returns the active BirdCoder locale id. */
    getSnapshot(): {
        active: string;
    };
    /** Observe active-locale changes. */
    subscribe(listener: () => void): () => void;
}
/** Minimal theme runtime consumed by the adapter. */
export interface DriveHostTheme {
    /** @returns the resolved host color scheme for the embedded Drive surface. */
    getColorScheme(): 'light' | 'dark';
    /** Observe resolved color-scheme changes. */
    subscribe(listener: () => void): () => void;
}
/** IAM session fields accepted by the SDKWork Drive session bridge. */
export interface DriveHostSession {
    accessToken?: string;
    authToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: {
        id?: string;
        displayName?: string;
        email?: string;
        avatar?: unknown;
    };
    context?: {
        tenantId?: string;
        userId?: string;
        organizationId?: string | null;
        sessionId?: string;
        appId?: string;
        environment?: string;
        deploymentMode?: string;
        authLevel?: string;
        dataScope?: string[];
        permissionScope?: string[];
        actorId?: string;
        actorKind?: string;
        deviceId?: string;
    };
}
/** Dependencies used to configure the SDKWork surface. */
export interface ConfigureDriveHostOptions {
    env: DriveHostEnvironment;
    iam: DriveHostIam;
    locale: DriveHostLocale;
    theme: DriveHostTheme;
}
/**
 * Convert the host IAM state into SDKWork's session format.
 * Identity fields are derived inside SDKWork Drive from JWT claims; the host
 * forwards credentials only and lets session tokens supersede env bootstrap.
 * @param session - current host IAM session, or null when signed out.
 * @param staticAccessToken - ui-sdkwork-env access token used by non-interactive deployments.
 * @returns a credential snapshot, or null when no tokens are available.
 */
export declare function toDriveSession(session: DriveHostSession | null, staticAccessToken: string): DriveSessionSnapshot | null;
/** Lifecycle handle returned after configuring the SDKWork host. */
export interface DriveHostAdapter {
    /** Dispose environment and IAM subscriptions. */
    dispose(): void;
}
/** Observable host-adapter operations used by focused integration tests. */
export interface DriveHostRuntime extends DriveHostAdapter {
    /** Start environment and IAM subscriptions. */
    start(): () => void;
    /** Register a listener for adapter changes. */
    subscribe(listener: () => void): () => void;
    /** @returns the revision used to remount after an environment switch. */
    getEnvironmentRevision(): number;
    /** @returns the current host session for the SDKWork session store. */
    readHostSession(): DriveSessionSnapshot | null;
    /** @returns the active SDKWork locale tag. */
    resolveHostLanguage(): string;
    /** @returns the active host color scheme for the embedded Drive surface. */
    resolveHostColorScheme(): 'light' | 'dark';
    /** Subscribe SDKWork to host locale changes. */
    subscribeHostLanguage(listener: (language: string) => void): () => void;
    /** Subscribe SDKWork to host color-scheme changes. */
    subscribeHostColorScheme(listener: (scheme: 'light' | 'dark') => void): () => void;
}
/** Configure the global SDKWork runtime ports for the embedded Drive. */
export declare function configureDriveHost(options: ConfigureDriveHostOptions): DriveHostAdapter;
/** Build an unconfigured adapter for focused host-bridge tests. */
export declare function createDriveHostRuntime(options: ConfigureDriveHostOptions): DriveHostRuntime;
/** Render the SDKWork Drive surface through the configured host adapter. */
export declare function DriveApp(): ReactNode;
//# sourceMappingURL=driveHost.d.ts.map