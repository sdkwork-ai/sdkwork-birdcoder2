import type { ReactNode } from 'react';
import type { DesktopWindowControls } from '@deepseek-ai/dsh-client-connection/client';
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Which OS's window-control conventions the cluster draws. */
export type WindowControlsPlatform = 'win32' | 'darwin' | 'linux' | 'other';
/**
 * Map a Chromium platform identifier to the supported window-control metrics.
 * @param raw - the platform string, e.g. "Win32", "MacIntel", "Linux x86_64".
 * @returns the convention set; unknown strings fall back to the default.
 */
export declare function resolvePlatform(raw: string): WindowControlsPlatform;
/**
 * Resolve the host OS's window-control convention set from Chromium's
 * user-agent platform, falling back to `navigator.platform`.
 * @returns the convention set; unknown or absent platforms fall back to the default.
 */
export declare function platformOf(): WindowControlsPlatform;
/** Business face the plugin injects: the preload's window surface, when present. */
export interface WindowControlsInjected {
    /** The Electron preload surface; undefined in the browser composition. */
    windowControls: DesktopWindowControls | undefined;
    /** The host OS's window-control convention set (glyph size, placement). */
    platform: WindowControlsPlatform;
}
/** Full props of the inline Session-header utility occupant. */
export type WindowControlsProps = PropsRuntime<'conversation.session.header.utilities'> & InjectFace<WindowControlsInjected>;
/** Full props of the floating shell-overlay occupant. */
export type FloatingWindowControlsProps = PropsRuntime<'shell.overlay'> & InjectFace<WindowControlsInjected>;
/**
 * The inline occupant of `conversation.session.header.utilities`: reserves the
 * platform cluster width after the Session-log utility while the sole live
 * cluster stays anchored by `shell.overlay`.
 * @param props - session runtime share plus the injected window surface.
 * @returns the platform-sized spacer, or nothing without the preload surface.
 */
export declare function WindowControls({ windowControls, platform }: WindowControlsProps): ReactNode;
/**
 * The `shell.overlay` occupant: pins the sole control cluster to the window's
 * top-right across hero, Session-header, and details-panel states.
 * @param props - root runtime share (global session list) plus the injected window surface.
 * @returns the floating cluster, or nothing without the preload surface.
 */
export declare function FloatingWindowControls({ windowControls, platform }: FloatingWindowControlsProps): ReactNode;
//# sourceMappingURL=WindowControls.d.ts.map