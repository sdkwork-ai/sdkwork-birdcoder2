/**
 * The General-settings row for the desktop shell's close-to-tray preference: a
 * labeled switch over the `desktop` settings namespace. This plugin is the
 * desktop shell's chrome surface, so it owns the shell preference row; the
 * host-side namespace registration lives with the tray in the app's main
 * process. Renders nothing until the settings scope accepts a section (the row
 * never guesses a value it cannot read).
 */
import type { ReactNode } from 'react';
import type { PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createTraySettingsRowStore } from './tray-settings-store.ts';
/** Injected business face: the durable preference write. */
export interface TraySettingsRowInjected {
    /** Persist the close-to-tray preference. */
    setCloseToTray: (value: boolean) => void;
}
/** Full component props: root runtime share + store share + injected face. */
export type TraySettingsRowProps = PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createTraySettingsRowStore>> & TraySettingsRowInjected;
/**
 * Render the close-to-tray preference row.
 * @param props - composed slot props.
 * @returns the row element tree, or nothing before the scope has a value.
 */
export declare function TraySettingsRow({ setCloseToTray, useStore }: TraySettingsRowProps): ReactNode;
//# sourceMappingURL=TraySettingsRow.d.ts.map