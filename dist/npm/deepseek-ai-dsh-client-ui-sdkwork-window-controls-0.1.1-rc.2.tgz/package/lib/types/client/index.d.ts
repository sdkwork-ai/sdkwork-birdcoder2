/**
 * Desktop shell chrome plugin, browser half: contributes the custom
 * minimize/maximize/close cluster to the frame-wide shell overlay, reserves
 * its footprint in the Session header utilities (right of Session log), routes
 * tray-driven navigation (open/new session from the system tray menu) into the
 * sessions and workspaces services, and owns the close-to-tray preference row
 * in General settings. The row lives in the dsh-desktop-app bundle patch only,
 * so the web composition never loads this plugin; the components still guard
 * on the preload surface's presence (fixture mode, accidental composition).
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export type { FloatingWindowControlsProps, WindowControlsInjected, WindowControlsPlatform, WindowControlsProps, } from './WindowControls.tsx';
export type { TraySettingsRowInjected, TraySettingsRowProps } from './TraySettingsRow.tsx';
/** Required services: the slot registry, navigation services, and the settings transport. */
export declare const inject: string[];
/**
 * Client plugin body: register the header spacer and overlay control cluster,
 * wire tray navigation into the sessions/workspaces services, and register
 * the close-to-tray preference row. Target slots are declared by other
 * entries, so each registration rides `slots.inject` on its declaration
 * lifetime (late activation, redeclaration, teardown with the caller's fiber).
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map