/** Host loader entry for the browser-only window-controls plugin. */
/** Provides no host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map