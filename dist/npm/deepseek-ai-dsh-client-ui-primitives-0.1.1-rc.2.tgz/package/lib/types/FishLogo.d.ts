import type { IconProps } from './icons/props.ts';
/**
 * Render the product logo mark.
 * @param props.size - width in px (default 24; height keeps the icon's ratio).
 * @param props.className - extra class for layout placement.
 * @returns the logo img (aria-hidden; pair with the wordmark for accessibility).
 */
export declare function FishLogo({ size, className }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=FishLogo.d.ts.map